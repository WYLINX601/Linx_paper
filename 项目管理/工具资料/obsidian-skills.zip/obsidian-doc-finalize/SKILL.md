---
name: obsidian-doc-finalize
description: Finalize already-completed Obsidian documents only when the user explicitly asks to archive, promote, move, canonicalize, or finalize a document. Use after writing and revision are done to move the canonical file, archive duplicates, update explicit Obsidian wiki/path references, and run vault health checks. Do not use for ordinary drafting, rewriting, topic compilation, vault-grounded Q&A, or document improvement; use obsidian-knowledge-manager for general Obsidian knowledge lifecycle work.
---

# Obsidian Doc Finalize

Use this as the downstream closeout tool for completed Obsidian documents. It is intentionally narrower than `obsidian-knowledge-manager`.

## Use This When

- The user explicitly says the document is complete and asks to archive, promote, finalize, canonicalize, or move it.
- A raw or working document has become the canonical output, answer bank, report, playbook, or topic artifact.
- Older duplicates should be archived and explicit references should be updated after a canonical move.
- The task is mostly mechanical file organization and reference repair, not writing or knowledge synthesis.

## Do Not Use This When

- The user is still drafting, rewriting, filling gaps, brainstorming, or improving a document.
- The task is inbox intake, source compilation, atomic note extraction, topic wiki maintenance, vault-grounded Q&A, or output generation. Use `obsidian-knowledge-manager` instead.
- The user has not made the completion/archive intent explicit.
- The target involves compatibility assets such as `.obsidian`, `Assistants`, `0-主页`, `copilot-custom-prompts`, `Documents/7-Excalidraw`, or root AI instruction files, unless the user explicitly asks and references have been checked.

## Relationship To Obsidian Knowledge Manager

`obsidian-knowledge-manager` is the general vault lifecycle skill. This skill is only the final archival subflow for completed documents that need canonical movement, duplicate archiving, explicit reference replacement, and health checks.

## Workflow

1. Inspect the document and classify its KCS layer.
2. If it is still source material, keep it in `01_sources/...`.
3. If it is a reusable deliverable, training artifact, answer bank, report, or playbook, move the canonical version to `04_outputs/...`.
4. If it is a durable synthesis or concept hub, use `03_topics/...`.
5. If it is an atomic insight, use `02_notes/atomic/...`.
6. Archive older duplicates instead of deleting them when they may contain historical context.
7. Update all explicit `[[old/path]]` and plain old-path references.
8. Run the vault health check only after the task-level change is complete.

## Canonicalization Rules

- Keep exactly one canonical copy for actively used artifacts.
- Prefer the newest, most complete edited file as canonical.
- Move older same-name or superseded copies to an `archive/` folder near their original context.
- Do not move compatibility assets such as `Assistants`, `0-主页`, `copilot-custom-prompts`, `Documents/7-Excalidraw`, or root AI instruction files unless the user explicitly asks.
- Do not rewrite diary entries into outputs; human/AI co-authored reflection notes usually stay in `02_notes/reflect/...`.

## Scripted Path Update

Use `scripts/finalize_doc.py` for mechanical file moves and reference replacement.

Example:

```bash
python3 ~/.codex/skills/obsidian-doc-finalize/scripts/finalize_doc.py \
  --vault /Users/wangyuelin/Desktop/Obsidian/Linx_AI \
  --source "01_sources/interview/raw/2026-03-31-通用简历深挖问题库.md" \
  --target-dir "04_outputs/interview" \
  --target-name "通用简历深挖问题库.md" \
  --archive-duplicate "01_sources/interview/records/2026-03-31-通用简历深挖问题库.md" \
  --archive-dir "01_sources/interview/records/archive" \
  --remove-ds-store \
  --run-lint
```

The script only replaces explicit old file paths and explicit wiki links containing the old path stem. It does not guess ambiguous basename-only wiki links.

## Manual Finish

After the script runs:

- Open the moved canonical file and ensure frontmatter has an appropriate `type`, `status`, `updated`, `source`, and `topics` when applicable.
- Add the canonical file to the relevant topic page if it should be discoverable from a hub.
- Check whether the destination topic needs a `关键输出` link to this finalized document.
- If the finalized output created stable reusable insights, add them back to related atomic notes or topic pages instead of leaving them only in `04_outputs`.
- Check for obvious residue using `rg "old/path|old filename fragment" .`.
- Summarize the moved file, archived file, updated links, and health check result.

## Reference

Read `references/kcs-doc-finalize.md` if the layer decision is unclear or if the user asks for a summary of the process.
