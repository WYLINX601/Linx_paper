# KCS Document Finalization Reference

## Layer Heuristic

- `01_sources`: raw imported material, interview transcripts, original notes, source PDFs, uncompiled drafts.
- `02_notes`: reflections and atomic notes; use `02_notes/atomic` only for single reusable ideas.
- `03_topics`: synthesis hubs that organize links and current understanding around a topic.
- `04_outputs`: deliverables that are meant to be used directly, such as interview answer banks, playbooks, reports, resumes, project pages, and training artifacts.
- `05_meta`: rules, templates, scripts, indexes, reports, prompts, tooling.

## Document Completion Pattern

1. Collaborate with the user to fill missing answers or sections.
2. Merge the new answers into the active working output.
3. If the source file has become a polished tool or answer bank, promote it out of `raw`.
4. Archive older duplicates rather than deleting them when they may be useful for provenance.
5. Update explicit references.
6. Add the new canonical artifact to the topic hub.
7. Run `05_meta/scripts/kcs_lint.py`.

## Example From Interview System

The file `2026-03-31-通用简历深挖问题库.md` began as raw interview preparation material. After all blank answers were filled, it became a reusable training artifact. It was promoted to `04_outputs/interview/通用简历深挖问题库.md`, the older `records` copy was archived, and all explicit links were updated.
