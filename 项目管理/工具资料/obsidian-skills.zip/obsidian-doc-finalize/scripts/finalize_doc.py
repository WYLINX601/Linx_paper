#!/usr/bin/env python3
"""Finalize a completed Obsidian vault document.

Moves a canonical document, archives older duplicates, updates explicit
Obsidian wiki/path references, optionally removes .DS_Store files, and
optionally runs the vault health check.
"""

from __future__ import annotations

import argparse
import os
import shutil
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class Move:
    old_rel: str
    new_rel: str


def rel_path(path: Path, root: Path) -> str:
    return path.relative_to(root).as_posix()


def inside(path: Path, root: Path) -> bool:
    try:
        path.resolve().relative_to(root.resolve())
        return True
    except ValueError:
        return False


def resolve_vault_path(root: Path, value: str) -> Path:
    path = Path(value).expanduser()
    if not path.is_absolute():
        path = root / path
    path = path.resolve()
    if not inside(path, root):
        raise ValueError(f"path is outside vault: {value}")
    return path


def unique_archive_path(archive_dir: Path, original: Path) -> Path:
    stem = original.stem
    suffix = original.suffix
    candidate = archive_dir / f"{stem}_旧版{suffix}"
    i = 2
    while candidate.exists():
        candidate = archive_dir / f"{stem}_旧版_{i}{suffix}"
        i += 1
    return candidate


def move_file(src: Path, dst: Path, dry_run: bool) -> Move:
    if not src.exists():
        raise FileNotFoundError(src)
    if dst.exists():
        raise FileExistsError(dst)
    old_rel = rel_path(src, ROOT)
    new_rel = rel_path(dst, ROOT)
    print(f"move: {old_rel} -> {new_rel}")
    if not dry_run:
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(str(src), str(dst))
    return Move(old_rel=old_rel, new_rel=new_rel)


def archive_file(src: Path, archive_dir: Path, dry_run: bool) -> Move | None:
    if not src.exists():
        print(f"skip missing duplicate: {rel_path(src, ROOT) if inside(src, ROOT) else src}")
        return None
    if not dry_run:
        archive_dir.mkdir(parents=True, exist_ok=True)
    dst = unique_archive_path(archive_dir, src)
    return move_file(src, dst, dry_run)


def wiki_path_no_ext(rel: str) -> str:
    return rel[:-3] if rel.endswith(".md") else rel


def update_markdown_refs(root: Path, moves: list[Move], dry_run: bool) -> int:
    replacements: list[tuple[str, str]] = []
    for move in moves:
        old_no_ext = wiki_path_no_ext(move.old_rel)
        new_no_ext = wiki_path_no_ext(move.new_rel)
        replacements.extend(
            [
                (f"[[{old_no_ext}]]", f"[[{new_no_ext}]]"),
                (f"[[{move.old_rel}]]", f"[[{move.new_rel}]]"),
                (move.old_rel, move.new_rel),
                (old_no_ext, new_no_ext),
            ]
        )

    changed = 0
    for md in root.rglob("*.md"):
        if ".git" in md.parts:
            continue
        text = md.read_text(encoding="utf-8")
        new_text = text
        for old, new in replacements:
            new_text = new_text.replace(old, new)
        if new_text != text:
            changed += 1
            print(f"update refs: {rel_path(md, root)}")
            if not dry_run:
                md.write_text(new_text, encoding="utf-8")
    return changed


def remove_ds_store(root: Path, dry_run: bool) -> int:
    count = 0
    for path in root.rglob(".DS_Store"):
        count += 1
        print(f"remove: {rel_path(path, root)}")
        if not dry_run:
            path.unlink()
    return count


def run_lint(root: Path, lint_script: str, dry_run: bool) -> int:
    script = resolve_vault_path(root, lint_script)
    print(f"run lint: {rel_path(script, root)}")
    if dry_run:
        return 0
    result = subprocess.run([sys.executable, str(script)], cwd=root)
    return result.returncode


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--vault", default=os.getcwd(), help="Vault root. Defaults to cwd.")
    parser.add_argument("--source", required=True, help="Canonical source file to move.")
    parser.add_argument("--target-dir", required=True, help="Directory for canonical output.")
    parser.add_argument("--target-name", help="New filename. Defaults to source basename.")
    parser.add_argument("--archive-duplicate", action="append", default=[], help="Older duplicate to archive. Repeatable.")
    parser.add_argument("--archive-dir", help="Archive directory. Defaults to archive/ under duplicate parent.")
    parser.add_argument("--remove-ds-store", action="store_true", help="Remove .DS_Store files under vault.")
    parser.add_argument("--run-lint", action="store_true", help="Run KCS lint after changes.")
    parser.add_argument("--lint-script", default="05_meta/scripts/kcs_lint.py", help="KCS lint script path.")
    parser.add_argument("--dry-run", action="store_true", help="Print actions without modifying files.")
    return parser.parse_args()


ROOT: Path


def main() -> int:
    global ROOT
    args = parse_args()
    ROOT = Path(args.vault).expanduser().resolve()
    if not ROOT.exists():
        raise FileNotFoundError(ROOT)

    source = resolve_vault_path(ROOT, args.source)
    target_dir = resolve_vault_path(ROOT, args.target_dir)
    target_name = args.target_name or source.name
    target = target_dir / target_name

    moves: list[Move] = []
    moves.append(move_file(source, target, args.dry_run))

    for duplicate in args.archive_duplicate:
        dup = resolve_vault_path(ROOT, duplicate)
        archive_dir = resolve_vault_path(ROOT, args.archive_dir) if args.archive_dir else dup.parent / "archive"
        move = archive_file(dup, archive_dir, args.dry_run)
        if move:
            moves.append(move)

    changed = update_markdown_refs(ROOT, moves, args.dry_run)
    print(f"updated markdown files: {changed}")

    if args.remove_ds_store:
        removed = remove_ds_store(ROOT, args.dry_run)
        print(f"removed .DS_Store files: {removed}")

    if args.run_lint:
        return run_lint(ROOT, args.lint_script, args.dry_run)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
