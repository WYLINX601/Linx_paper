# Intake Reference

Use when importing, classifying, or routing new material into the vault.

## Routing

- `00_inbox/`: temporary entry point for new, unprocessed material.
- `01_sources/`: raw traceable material such as articles, papers, clippings, transcripts, datasets, source notes, and original project context.
- `02_notes/atomic/`: one reusable idea, mechanism, judgment, method, case, or long-term question.
- `03_topics/`: current best synthesis for a topic, with links to sources and notes.
- `04_outputs/`: deliverables meant to be used directly, such as reports, answer banks, playbooks, project documents, resumes, and slides.
- `05_meta/`: rules, templates, scripts, indexes, reports, prompts, and tooling.

## Intake Checklist

- Preserve raw source text and provenance whenever useful.
- Add or keep frontmatter with `type`, `status`, `created`, `updated`, `source`, and `topics` when applicable.
- For web clippings, keep original URL, title, author, published date, and clipped/accessed date if available.
- For papers or books, keep citation metadata and file/source backlink if available.
- For screenshots or images, keep the local asset path and context explaining what the image supports.
- Do not over-summarize source files; move interpretation into notes/topics.

## Classification Questions

- What is this material about?
- Is it raw source, personal understanding, a topic synthesis, a deliverable, or system metadata?
- Should it land as source, concept, topic, output, or remain in inbox until clarified?
- Which existing topic should it link to?
- What reusable concepts or questions does it create?
- Does it change an existing judgment or output?

## Guardrails

- Do not move `.obsidian/`, `Assistants/`, `0-主页/`, `copilot-custom-prompts/`, `Documents/7-Excalidraw/`, or root AI instruction files unless explicitly requested.
- Do not delete meaningful source material during intake.
- Do not treat private speculation as source provenance.
- If placement is ambiguous, keep raw material in `01_sources/...` or `00_inbox/` and add a note explaining the ambiguity.
