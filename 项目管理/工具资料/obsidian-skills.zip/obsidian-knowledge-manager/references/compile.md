# Compile Reference

Use when converting source material into atomic notes, topic updates, or knowledge outputs.

## Compilation Loop

1. Inspect the source and existing related topics.
2. Identify reusable concepts, mechanisms, methods, cases, judgments, and long-term questions.
3. Create or update `02_notes/atomic/...` only for stable single ideas.
4. Update the relevant `03_topics/...` page when several notes support the same theme.
5. Generate or update `04_outputs/...` only when the user wants a reusable deliverable.
6. Feed stable output insights back into notes/topics instead of leaving them trapped in outputs.
7. Link source, note, topic, and output artifacts in both directions where useful.
8. Run the vault health check after batch edits.

## Atomic Note Criteria

Create an atomic note when the material contains:

- One reusable concept.
- One method or step pattern.
- One counterintuitive judgment.
- One transferable case.
- One durable open question.

Do not create an atomic note for:

- Temporary tasks.
- Context-free excerpts.
- Low-value noise.
- A broad summary that belongs in a source file or topic page.

## Atomic Note Shape

Use the vault template style:

```markdown
---
type: atomic-note
status: draft
created:
updated:
source:
topics:
---

# Title

## 定义

## 核心机制

## 例子

## 我的判断

## 相关链接
```

## Compilation Quality Bar

- Keep the claim small enough to be reused in future outputs.
- Link at least one source and one topic when possible.
- Prefer rewriting into the user's knowledge language over copying long excerpts.
- If a topic already has enough relevant notes, update the topic instead of creating more fragmented notes.
- Record genuine knowledge gaps as `Open Problems` in the relevant topic.
