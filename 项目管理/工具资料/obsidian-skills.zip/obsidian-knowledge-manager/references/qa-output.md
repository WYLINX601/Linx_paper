# Vault-Grounded Q&A And Output Reference

Use when the user asks questions that should be answered from the vault or asks for durable outputs.

## Answering From The Vault

- Search relevant topics, sources, notes, and outputs before answering.
- Prefer local vault content over web search unless the user asks for current external information or the fact is time-sensitive.
- Cite vault artifacts with wiki links inside generated Markdown when saving to the vault.
- Clearly separate source-backed facts, synthesis, and inference.

## Durable Output Rules

- Create durable answers as Markdown outputs under `04_outputs/...` when the user asks for a report, playbook, answer bank, project doc, slide draft, or reusable artifact.
- Use Marp Markdown only when the user asks for slides or presentation-ready structure.
- Create charts or data artifacts only when they add analytical value and save them where the vault can reference them.
- Every durable output should link at least one relevant topic when possible.
- If the output creates stable new ideas, feed them back into `02_notes/atomic` or the relevant `03_topics` page.
- Default to vault persistence for reusable query results rather than leaving the answer only in chat.

## Output Frontmatter

Use fields such as:

```yaml
---
type: output
status: draft
created:
updated:
source:
topics:
---
```

Adjust `type` to a more specific value only if the vault already uses it.

## Guardrails

- Do not answer from memory when the user explicitly asks for vault-grounded work; inspect the vault.
- Do not bury useful generated outputs in the terminal if the user asked for Obsidian persistence.
- Do not overwrite older deliverables unless the user asks to replace them; create a new version or ask if the overwrite is risky.
- Use `obsidian-doc-finalize` only after the user says the output is complete and asks to archive, promote, canonicalize, move, or finalize it.
