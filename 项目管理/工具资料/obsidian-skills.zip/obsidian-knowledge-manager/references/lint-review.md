# Lint And Health Review Reference

Use when reviewing knowledge system health, interpreting reports, or proposing cleanup.

## Standard Check

From the vault root, run:

```bash
python3 05_meta/scripts/kcs_lint.py
```

Then inspect `05_meta/index/知识系统体检报告.md`.

## Review Priorities

- Inbox load: unprocessed `00_inbox` files.
- Missing frontmatter: files that cannot be reliably classified.
- Orphaned notes/topics: `02_notes` or `03_topics` files without useful links.
- Topic completeness: missing source blocks, related-topic blocks, key-output blocks, or Open Problems.
- Compatibility assets: confirm `.obsidian`, `Assistants`, `0-主页`, `copilot-custom-prompts`, and `Documents/7-Excalidraw` are not treated as ordinary knowledge content.
- Duplicate or superseded documents: suggest finalize/archive only when the user asks to perform it.
- Output back-links: outputs that do not link back to any topic.
- Concept assignment: atomic notes missing `topics:` or lacking a clear topic home.
- Old path residue: legacy links that still point to pre-migration locations.
- Topic gaps: notes that should update a topic, topics without sources, or Open Problems that need follow-up.

## Health Review Output

Summarize:

- What is healthy.
- What is blocking retrieval or reuse.
- Highest-priority fixes.
- Suggested next research or compilation actions.
- Whether any action should be delegated to `obsidian-doc-finalize`.

## Guardrails

- Running lint may update only the lint report; do not treat that as knowledge rewriting.
- Do not delete old documents just because they are duplicates; archive when provenance matters.
- Do not perform large migrations from a health review alone. Propose or execute only the specific requested maintenance task.
