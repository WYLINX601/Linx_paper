# Topic Maintenance Reference

Use when maintaining `03_topics` pages.

## Topic Purpose

A topic page is the current best synthesis for a domain, not a source dump. It should help the user understand the topic, find key material, and identify next research questions.

## Recommended Structure

```markdown
# Topic

## 定义

## 核心问题

## 方法/框架

## 关键案例

## 相关原子卡片

## Open Problems

## 学习路径
```

## Maintenance Rules

- Read existing topic content before editing; preserve useful user wording.
- Merge repeated claims instead of appending duplicate bullets.
- Promote mature atomic notes into the topic synthesis.
- Keep `关键资料` or equivalent source links focused on the most important materials.
- Keep `相关原子卡片` useful; do not mechanically list every weakly related note.
- Keep `相关主题` present for meaningful neighboring topics.
- Keep `关键输出` present for reusable outputs that represent the topic in action.
- Add `Open Problems` for unresolved questions, missing sources, contradictions, or research directions.
- Link outputs that depend on the topic when they are durable and useful.
- Mark only a small number of topics as `canonical`; these are first-tier wiki entry points.

## When To Update A Topic

- New source material changes the topic's current best understanding.
- Five or more atomic notes accumulate around the same topic.
- A user asks for a topic-level synthesis, learning path, report, or research map.
- A health check finds an orphaned note or weak topic coverage.

## Guardrails

- Do not convert a topic page into a chronological log.
- Do not move mature outputs into topics; link them from the topic instead.
- Do not invent a consensus when sources conflict. State the disagreement and add an Open Problem.
