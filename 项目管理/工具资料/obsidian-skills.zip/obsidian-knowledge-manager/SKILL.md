---
name: obsidian-knowledge-manager
description: Manage and evolve an Obsidian knowledge vault during AI-assisted knowledge work. Use when the task involves vault knowledge lifecycle operations such as inbox intake, source classification, atomic note extraction, topic wiki maintenance, vault-grounded Q&A, Markdown output generation, knowledge linking, output回流, or knowledge health review. Do not use as the primary skill for generic drafting, interview coaching, PRD writing, academic reasoning, coding, or creative editing unless the user also asks to organize, link, compile, or persist the result inside the Obsidian vault. Do not perform final archival moves unless the user explicitly asks to archive, promote, move, canonicalize, or finalize a completed document; then use obsidian-doc-finalize.
---

# Obsidian Knowledge Manager

Use this as the Obsidian vault knowledge lifecycle layer, not as a generic writing skill.

## Use This When

- The user asks to process `00_inbox`, imported source material, web clippings, papers, notes, or other vault content.
- The task involves classifying content into `01_sources`, `02_notes`, `03_topics`, `04_outputs`, or `05_meta`.
- The user asks to compile source material into atomic notes or topic wiki pages.
- The user asks a vault-grounded question and wants a Markdown, Marp, chart, report, or other durable output saved back to the vault.
- The task involves adding links, frontmatter, source/topic/output relationships, Open Problems, indexes, or knowledge health review.
- The task involves wiki entry maintenance, topic canonicalization, concept navigation, or output-to-wiki feedback.

## Do Not Use This When

- The user only asks for ordinary drafting, rewriting, interview coaching, PRD writing, academic reasoning, coding, or creative editing without asking to persist or organize the result in the vault.
- The user explicitly says a document is finished and asks to archive, promote, canonicalize, move to outputs, finalize, or update references. Use `obsidian-doc-finalize` for that downstream closeout workflow.
- The task is to move compatibility assets such as `.obsidian`, `Assistants`, `0-主页`, `copilot-custom-prompts`, `Documents/7-Excalidraw`, or root AI instruction files, unless the user explicitly asks and references have been checked.

## Collaboration Model

- Domain or writing skills decide what the content should say.
- This skill decides how the content enters the vault, how it is linked, where it should live, and how it becomes reusable.
- This skill maintains the wiki runtime layer: entry indexes, topic completeness, concept-to-topic routing, and output feedback loops.
- `obsidian-doc-finalize` handles completed-document archival moves, duplicate archiving, explicit reference replacement, and final health checks.

## Standard Vault Rules

- Start by reading the vault `README.md` when the task touches an unfamiliar vault area.
- New inputs go to `00_inbox/`.
- Raw, traceable materials go to `01_sources/`.
- Stable single ideas go to `02_notes/atomic/`.
- Current best understanding and concept hubs go to `03_topics/`.
- Deliverables such as reports, answer banks, project docs, slides, and publishable outputs go to `04_outputs/`.
- Rules, templates, reports, scripts, indexes, and tooling go to `05_meta/`.
- After batch changes, run `python3 05_meta/scripts/kcs_lint.py` from the vault root and review `05_meta/index/知识系统体检报告.md`.

## Workflow Router

- **Intake**: Read `references/intake.md` when importing, classifying, or routing new material.
- **Compile**: Read `references/compile.md` when turning sources into atomic notes or topic updates.
- **Topic maintenance**: Read `references/topic-maintenance.md` when updating `03_topics` pages.
- **Vault-grounded output**: Read `references/qa-output.md` when answering from the vault or creating durable outputs.
- **Health review**: Read `references/lint-review.md` when checking system health, duplicates, gaps, orphaned notes, or next research directions.

## Operating Principles

- Prefer preserving raw source and adding synthesized notes over overwriting source material.
- Do not invent source provenance. If source metadata is missing, mark it as missing or infer only when clearly supported.
- Keep topic pages as the current best synthesis, not link dumps.
- Treat outputs as first-class knowledge assets: link them to topics and feed stable insights back into notes/topics.
- Prefer semantic restructuring and link repair over large directory migrations.
- Only propose directory-level migrations when semantics are clearly wrong, mechanical link updates are feasible, and the gain is materially larger than the maintenance cost.
- When a deterministic local script exists, prefer using it for repeatable checks or mechanical operations.
