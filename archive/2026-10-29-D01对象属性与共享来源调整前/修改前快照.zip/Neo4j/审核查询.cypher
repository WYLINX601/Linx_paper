// D01V01：实际执行并验证的审核查询。每段分别运行。
// 全部数据为合成；不是实测。

// Q00：对象与数据层浏览
MATCH (a:D01V01)-[r]->(b:D01V01) WHERE type(r) IN ['BOT_HAS_BUILDING','BOT_HAS_SPACE','HAS_MEASUREMENT_SET','HAS_COMPARISON','COMPARES_SUBJECT','COMPARES_REFERENCE'] RETURN a,r,b;

// Q01 民居组成
MATCH (u:D01V01:DwellingUnit)-[r:BOT_HAS_BUILDING|BOT_HAS_SPACE]->(x:D01V01)
RETURN u.name AS unit,x.id AS id,x.name AS object,type(r) AS relation,x.botClassIri AS botClass,r.botPropertyIri AS botProperty ORDER BY id;

// Q02 水平尺度与比例
MATCH (b:D01V01:Building)-[:HAS_MEASUREMENT_SET]->(m:D01V01:MeasurementSet)-[:USES_DATUM]->(d:D01V01:ReferenceDatum)
WHERE m.activeForDemo=true AND m.scenario='T0' AND m.recordVersion='v1'
RETURN b.id AS id,b.name AS building,m.id AS input,m.widthM AS widthM,m.depthM AS depthM,
CASE WHEN m.unit='m' AND m.depthM>0 THEN m.widthM/m.depthM END AS widthDepthRatio,
m.widthDirection AS widthDirection,m.depthDirection AS depthDirection,m.boundaryBasis AS boundary,d.id AS datum ORDER BY id;

// Q03 自身高度与高宽比
MATCH (b:D01V01:Building)-[:HAS_MEASUREMENT_SET]->(m:D01V01:MeasurementSet)-[:USES_DATUM]->(d:D01V01:ReferenceDatum)
WHERE m.activeForDemo=true AND m.scenario='T0' AND m.recordVersion='v1'
WITH b,m,d,CASE WHEN m.unit='m' AND m.eaveZM IS NOT NULL AND m.groundZM IS NOT NULL THEN m.eaveZM-m.groundZM END AS ownHeight
RETURN b.id AS id,b.name AS building,m.groundZM AS groundZM,m.eaveZM AS eaveZM,ownHeight AS ownEaveHeightM,
CASE WHEN m.widthM>0 THEN ownHeight/m.widthM END AS eaveWidthRatio,m.heightBasis AS basis,d.id AS datum ORDER BY id;

// Q04 檐口位置比较及保存结果重算
MATCH (c:D01V01:ComparisonResult)-[:COMPARES_SUBJECT]->(subject:D01V01:Building),
(c)-[:COMPARES_REFERENCE]->(reference:D01V01:Building),
(c)-[:USES_INPUT {role:'minuend'}]->(b:D01V01:MeasurementSet)-[:USES_DATUM]->(db:D01V01:ReferenceDatum),
(c)-[:USES_INPUT {role:'subtrahend'}]->(a:D01V01:MeasurementSet)-[:USES_DATUM]->(da:D01V01:ReferenceDatum),
(c)-[:APPLIES_RULE]->(rule:D01V01:AnalysisRule)
WITH c,subject,reference,a,b,da,db,rule,
CASE WHEN da=db AND a.unit='m' AND b.unit='m' AND a.scenario=b.scenario AND a.eaveZM IS NOT NULL AND b.eaveZM IS NOT NULL THEN b.eaveZM-a.eaveZM END AS delta
RETURN subject.name AS subject,reference.name AS reference,delta AS recomputedM,c.valueM AS storedM,
CASE WHEN delta IS NULL THEN '不可判定' WHEN abs(delta-c.valueM)<1e-9 THEN '保存结果与输入一致' ELSE '结果过期，需重算' END AS checkStatus,
rule.ruleId AS rule,da.id AS referenceDatum,db.id AS subjectDatum;

// Q05 结果到输入及来源追溯
MATCH (c:D01V01:ComparisonResult)-[input:USES_INPUT]->(m:D01V01:MeasurementSet)-[:SUPPORTED_BY]->(e:D01V01:Evidence),
(m)-[:USES_DATUM]->(d:D01V01:ReferenceDatum),
(c)-[:APPLIES_RULE]->(rule:D01V01:AnalysisRule)
RETURN c.id AS result,input.role AS role,input.field AS field,m.id AS inputRecord,m.eaveZM AS inputValue,m.unit AS unit,m.scenario AS scenario,m.recordVersion AS inputVersion,d.id AS datum,
e.name AS evidence,e.sourceKind AS evidenceKind,e.sourcePath AS sourcePath,e.locator AS locator,rule.ruleId AS rule,rule.expression AS expression ORDER BY role;

// Q06 范围与BOT类别边界
MATCH (n:D01V01)
RETURN count(n) AS nodes,
sum(CASE WHEN n:Building THEN 1 ELSE 0 END) AS buildings,
sum(CASE WHEN n:Space THEN 1 ELSE 0 END) AS spaces,
sum(CASE WHEN n:MeasurementSet THEN 1 ELSE 0 END) AS inputRecords,
sum(CASE WHEN n:Building AND n:Space THEN 1 ELSE 0 END) AS disjointClassConflicts,
sum(CASE WHEN n.dataMode<>'synthetic' OR n.dataMode IS NULL THEN 1 ELSE 0 END) AS unmarkedSyntheticNodes;

// Q07 缺失与不可比输入反例（只读参数，不写库）；参数见查询核验记录，本段为只读反例测试。
UNWIND $fixtures AS t
WITH t,CASE
 WHEN t.a.eaveZM IS NULL OR t.b.eaveZM IS NULL THEN '不可判定：缺少檐口高程'
 WHEN coalesce(t.a.unit,'')<>'m' OR coalesce(t.b.unit,'')<>'m' THEN '不可判定：单位未统一'
 WHEN t.a.datum IS NULL OR t.b.datum IS NULL OR t.a.datum<>t.b.datum THEN '不可判定：基准不一致'
 WHEN t.a.scenario IS NULL OR t.b.scenario IS NULL OR t.a.scenario<>t.b.scenario THEN '不可判定：情境不一致'
 ELSE '可计算' END AS status
RETURN t.name AS fixture,status,CASE WHEN status='可计算' THEN t.b.eaveZM-t.a.eaveZM END AS deltaM ORDER BY fixture;

// Q08 比例分母反例（只读参数，不写库）；参数见查询核验记录，本段为只读反例测试。
UNWIND $fixtures AS t
RETURN t.name AS fixture,
CASE WHEN t.width IS NULL OR t.depth IS NULL THEN '不可判定：输入缺失'
 WHEN t.width<=0 OR t.depth<=0 THEN '不可判定：尺寸非正'
 ELSE '可计算' END AS status,
CASE WHEN t.width>0 AND t.depth>0 THEN t.width/t.depth END AS ratio ORDER BY fixture;

