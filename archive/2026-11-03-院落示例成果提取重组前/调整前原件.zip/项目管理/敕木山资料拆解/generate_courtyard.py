#!/usr/bin/env python3
"""Build courtyard review views from the sole Paper master (transferred inputs).

No vault/database writes. Download source and listed PNGs through mac-paper;
run into scratch, inspect, then publish with latest-SHA protection.
"""
import argparse
import base64
import hashlib
import json
import re
from pathlib import Path

VERSION = 'CMS-CY-render-1.0'
PAGE = '院落与外部空间审核.html'
NOTE = '院落试例说明.md'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def unique(items, what):
    ids = [x['id'] for x in items]
    if len(ids) != len(set(ids)):
        raise ValueError(f'duplicate {what} IDs')
    return {x['id']: x for x in items}


def validate(master, text_dir=None):
    p = master['courtyard_pilot']
    nodes, rels, evs = (unique(p[k], k) for k in ['nodes', 'relations', 'evidence'])
    if set(nodes) & set(rels):
        raise ValueError('node/relation ID collision')
    papers = {x['key']: x for x in master['papers']}
    materials = {x['id']: (paper['key'], x) for paper in master['papers'] for x in paper['materials']}
    old_objects = {x['id'] for x in master['objects']}
    checks = []

    def check(ok, label):
        if not ok:
            raise ValueError(label)
        checks.append(label)

    for e in evs.values():
        check(e['paper'] in papers, e['id'] + ': source exists')
        check(e['material'] in materials, e['id'] + ': material exists')
        pk, m = materials[e['material']]
        check(pk == e['paper'] and m['pdf_page'] == e['pdf_page'], e['id'] + ': source/page aligned')
        claims = {c['id'] for c in papers[pk]['claims']}
        check(set(e['claim_ids']) <= claims, e['id'] + ': legacy claims valid')
        if e.get('image_material'):
            ik, im = materials[e['image_material']]
            check(ik == pk and bool(im.get('asset')), e['id'] + ': image source aligned')
        if text_dir:
            text = (Path(text_dir) / f'{pk}-selected.txt').read_text()
            norm = lambda s: re.sub(r'\s+', '', s)
            check(norm(e['quote']) in norm(text), e['id'] + ': short quote matches PDF text')
    for n in nodes.values():
        check(bool(n['evidence']) and set(n['evidence']) <= evs.keys(), n['id'] + ': evidence valid')
        check(n['geometry_mapping'] is None, n['id'] + ': no fabricated 3D mapping')
        check(set(n['legacy_refs']) <= old_objects, n['id'] + ': original IDs retained')
        for f in n['fields']:
            check(bool(f['evidence']) and set(f['evidence']) <= set(n['evidence']), n['id'] + ': field support explicit')
    for r in rels.values():
        check(r['source'] in nodes and r['target'] in nodes, r['id'] + ': endpoints valid')
        check(bool(r['evidence']) and set(r['evidence']) <= evs.keys(), r['id'] + ': evidence valid')
        check(r['formal_relation'] is None and r['geometry_mapping'] is None, r['id'] + ': not frozen Schema or mapped geometry')
        if r['kind'] == '文献模式':
            check(all(nodes[k]['kind'] == '文献模式' for k in [r['source'], r['target']]), r['id'] + ': no pattern propagation to case')
        for im in r.get('illustrations', []):
            check(bool(materials[im][1].get('asset')), r['id'] + ': illustration exists')
    covered_nodes, covered_edges = set(), set()
    for v in p['views']:
        vn = set(v['nodes'])
        vr = [r for r in rels.values() if v['id'] in r['views']]
        check(vn <= nodes.keys(), v['id'] + ': node selection valid')
        check(all(r['source'] in vn and r['target'] in vn for r in vr), v['id'] + ': no dangling displayed edges')
        check(v['initial'] in vn | {r['id'] for r in vr}, v['id'] + ': initial selection valid')
        covered_nodes.update(vn)
        covered_edges.update(r['id'] for r in vr)
    check(covered_nodes == nodes.keys() and covered_edges == rels.keys(), 'all records reachable in views')
    alts = [r for r in rels.values() if r.get('alternative_group')]
    check(len(alts) == 2 and len({r['alternative_group'] for r in alts}) == 1, 'two source alternatives kept in one explicit group')
    check(rels['CMS-CY-R05']['evidence'] == ['CY-E03'] and rels['CMS-CY-R06']['evidence'] == ['CY-E03'], 'parallel relation supported by text not caption')
    return checks


def build(source, images_dir, output_dir, template=None, text_dir=None):
    source, images_dir, output_dir = map(Path, [source, images_dir, output_dir])
    master = json.loads(source.read_text())
    p = master['courtyard_pilot']
    checks = validate(master, text_dir)
    papers = {x['key']: {k: x[k] for k in ['key', 'title', 'authors', 'year', 'attachment', 'imprint', 'sha256']} for x in master['papers'] if x['key'] in {e['paper'] for e in p['evidence']}}
    materials = {x['id']: x for paper in master['papers'] for x in paper['materials']}
    image_ids = sorted({e['image_material'] for e in p['evidence'] if e.get('image_material')} | {im for r in p['relations'] for im in r.get('illustrations', [])})
    images = {}
    for i in image_ids:
        m = materials[i]
        f = images_dir / Path(m['asset']).name
        provenance = json.loads(Path(str(f) + '.provenance.json').read_text())
        if provenance['source_path'] != m['asset'] or provenance['sha256'] != sha(f):
            raise ValueError('Image provenance mismatch: ' + i)
        images[i] = {k: m[k] for k in ['title', 'locator', 'asset', 'source_key', 'boundary']}
        images[i].update(sha256=sha(f), data='data:image/png;base64,' + base64.b64encode(f.read_bytes()).decode())
    payload = dict(pilot=p, papers=papers, images=images, master_sha256=sha(source), generator_version=VERSION)
    snapshot = json.dumps(payload, ensure_ascii=False).replace('<', '\\u003c')
    template = Path(template) if template else Path(__file__).with_name('courtyard_template.html')
    html = template.read_text()
    if html.count('__SNAPSHOT__') != 1:
        raise ValueError('Expected one template insertion marker')
    output_dir.mkdir(parents=True, exist_ok=True)
    (output_dir / PAGE).write_text(html.replace('__SNAPSHOT__', snapshot))
    note = ['---', 'type: research-deliverable', 'status: evidence-modeling-pilot-review-pending', 'updated: 2026-11-02', 'generated_from: 拆解主源.json#courtyard_pilot', '---', '', '# 院落与外部空间：资料建模试例', '', f'> {p["status"]}。版本 {p["version"]}；本页为同源生成视图，不手工维护第二套事实。', '', f'[打开可点击网络审核]({PAGE}) · [返回成果入口](README.md) · [维护主源](拆解主源.json) · [实际核验范围](院落试例核验.json)', '', '## 先看思路', '', p['purpose'], '', '具体资料案例接续具名对象，模式视图保存一般组织和词汇，差异视图保留不同来源主张。来源长期保留；确认同一现实对象且尺度相符后才衔接实例身份。没有证据时，不把这些角色拼成“标准原型”。', '', '## 三个视图', '']
    for v in p['views']:
        note += [f'### {v["name"]}', '', v['description'], '']
    note += ['## 最小表达约定', ''] + [f'- {s}' for s in p['conventions']]
    note += ['', '## 对象与资料角色', '', '| ID／对象 | 身份与范围 | 当前描述 | 后续用途 |', '|---|---|---|---|']
    cell = lambda s: str(s).replace('|', '／').replace('\n', '<br>')
    for n in p['nodes']:
        desc = '<br>'.join(f'{f["label"]}：{f["value"]}〔{", ".join(f["evidence"])}〕' for f in n['fields'])
        note += [f'| {n["id"]}<br>{n["name"]} | {cell(n["kind"]+"；"+n["scope"])} | {cell(desc)} | {cell(n["use"])} |']
    note += ['', '## 联系及证据边界', '', '| ID／联系 | 端点 | 描述与证据 | 未知与采用条件 |', '|---|---|---|---|']
    for r in p['relations']:
        note += [f'| {r["id"]}<br>{r["name"]}〔{r["kind"]}〕 | {r["source"]} → {r["target"]} | {cell(r["summary"])}〔{", ".join(r["evidence"])}〕 | {cell("；".join(r["unknowns"]))}<br>{cell(r["use"])} |']
    note += ['', '## 反哺位置与采用条件', '', '| 目标 | 本例建议 | 采用条件 | 当前状态 |', '|---|---|---|---|']
    for f in p['feedback']:
        note += ['| ' + ' | '.join(cell(f[k]) for k in ['target', 'proposal', 'condition', 'status']) + ' |']
    note += ['', '## 原句与来源定位', '', '引文只是短摘；支持范围按原段和逐项说明，不把图片当平行关系量测。', '']
    for e in p['evidence']:
        paper = papers[e['paper']]
        note += [f'### {e["id"]}', '', f'> {e["quote"]}', '', f'{"、".join(paper["authors"])}（{paper["year"]}）《{paper["title"]}》；{e["locator"]}；Zotero `{e["paper"]}`／附件 `{paper["attachment"]}`；[打开原页](zotero://open-pdf/library/items/{paper["attachment"]}?page={e["pdf_page"]})。', '', f'- 归属：{e["attribution"]}', f'- 支持：{e["support"]}', f'- 边界：{e["boundary"]}', '']
    note += ['## 图像入口', '']
    for i in image_ids:
        a = images[i]
        note += [f'- [{i} {a["title"]}](../../{a["asset"]})：{a["locator"]}；原文图像裁切副本，图文：{"、".join(papers[a["source_key"]]["authors"])}。']
    note += ['', '## 阅读、复核与实施边界', '', p['reading_review']['coverage'], '', p['review_response']['independent_coverage'], '', '主会话落实独立建议：']
    note += [f'- {s}' for s in p['review_response']['main_session_changes']]
    note += ['', p['review_response']['followup_status'], '', '依据：' + '；'.join(p['basis']), '']
    note += ['- ' + s for s in p['acceptance_boundary']]
    note += ['', f'主源 SHA-256：`{sha(source)}`；生成器：`{VERSION}`。', '']
    (output_dir / NOTE).write_text('\n'.join(note))
    manifest = dict(generator_version=VERSION, source_sha256=sha(source), counts={'nodes_or_roles':len(p['nodes']), 'review_relations':len(p['relations']), 'evidence_fragments':len(p['evidence']), 'sources':len(papers), 'embedded_images':len(images), 'views':len(p['views'])}, checks=checks, outputs={n:sha(output_dir/n) for n in [PAGE, NOTE]}, image_sha256={k:v['sha256'] for k,v in images.items()}, template_sha256=sha(template))
    (output_dir / 'build-checks.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2)+'\n')
    return manifest


if __name__ == '__main__':
    a = argparse.ArgumentParser(description=__doc__)
    for flag in ['source', 'images-dir', 'output-dir']:
        a.add_argument('--'+flag, required=True)
    a.add_argument('--template')
    a.add_argument('--evidence-text-dir')
    args = a.parse_args()
    result = build(args.source, args.images_dir, args.output_dir, args.template, args.evidence_text_dir)
    print(json.dumps({'counts': result['counts'], 'checks_passed':len(result['checks']), 'outputs':result['outputs']}, ensure_ascii=False, indent=2))
