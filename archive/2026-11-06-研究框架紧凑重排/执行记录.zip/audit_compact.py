from pathlib import Path
import json, itertools, math
from PIL import Image
P=Path(__file__).resolve().parent
L=json.loads((P/'compact-layout.json').read_text());S=json.loads((P/'candidate-scene.json').read_text());D={e['id']:e for e in S['elements']};old=json.loads((P/'source-scene.json').read_text())
leaf={v['id'] for v in L['leaves']}; head={v['headId'] for v in L['groups']}
def rect(e):return (e['x'],e['y'],e['x']+e['width'],e['y']+e['height'])
def over(a,b,p=0):return min(a[2],b[2])-max(a[0],b[0])>p and min(a[3],b[3])-max(a[1],b[1])>p
def hit(a,b,r):
 if abs(a[0]-b[0])<.001:return r[0]+1<a[0]<r[2]-1 and max(min(a[1],b[1]),r[1]+1)<min(max(a[1],b[1]),r[3]-1)
 if abs(a[1]-b[1])<.001:return r[1]+1<a[1]<r[3]-1 and max(min(a[0],b[0]),r[0]+1)<min(max(a[0],b[0]),r[2]-1)
 return False
ov=[];lines=[];capt=[];bounds=[]
for a,b in itertools.combinations(leaf,2):
 if over(rect(D[a]),rect(D[b]),.2):ov.append([a,b])
for e in S['elements']:
 if e['type']=='text' and e.get('containerId'):
  r=rect(e);c=rect(D[e['containerId']]);
  if r[0]<c[0]-1 or r[1]<c[1]-1 or r[2]>c[2]+1 or r[3]>c[3]+1:bounds.append(e['id'])
 if e['type']=='arrow':
  pts=[(e['x']+p[0],e['y']+p[1]) for p in e['points']];ends={e['startBinding']['elementId'],e['endBinding']['elementId']}
  for id in leaf-ends:
   if any(hit(a,b,rect(D[id])) for a,b in zip(pts,pts[1:])):lines.append([e['id'],id])
texts=[e for e in S['elements'] if e['type']=='text' and any(g.startswith('compact-edge-') for g in e.get('groupIds',[]))]
for t in texts:
 for id in leaf|head:
  if over(rect(t),rect(D[id]),.2):capt.append([t['id'],id,t['originalText']])
cc=[[a['id'],b['id'],a['originalText'],b['originalText']] for a,b in itertools.combinations(texts,2) if over(rect(a),rect(b),.2)]
result={'revision':S['revision'],'pagesComplete':S['pagesComplete'],'nativeElements':len(D),'retainedIds':set(D)=={e['id'] for e in old['elements']},'textCount':sum(e['type']=='text' for e in D.values()),'terminalConcepts':len(leaf),'leafFontSizes':sorted({D[x['id']]['fontSize'] for e in [D[k] for k in leaf] for x in e['boundElements'] if x['type']=='text'}),'boundTextOverflows':bounds,'leafCardOverlaps':ov,'arrowsThroughLeaves':lines,'captionCardOverlaps':capt,'captionOverlaps':cc,'imageElements':sum(e['type']=='image' for e in D.values())}
(P/'candidate-audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps(result,ensure_ascii=False))
im=Image.open(P/'native-preview.png');im.load();r=json.loads((P/'export-png-receipt.json').read_text())['response']['data'];m=r['sceneToPreview'];sb=m['sceneBounds'];sx=im.width/sb['width'];sy=im.height/sb['height']
for n,(y0,y1) in L['chapterBounds'].items():
 crop=im.crop((0,max(0,int((y0-sb['y'])*sy)),im.width,min(im.height,int((y1-sb['y'])*sy)+2)))
 crop.save(P/f'native-ch{n}.png')
 if n=='3':crop.save(P/'third-chapter-detail.png')
print('Chapter crops created from actual native export.')
