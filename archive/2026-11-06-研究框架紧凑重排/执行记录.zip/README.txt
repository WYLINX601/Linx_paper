Historical execution evidence only. Read current source and SHA before new work. Do not blindly replay.
