"""Layout-only transformation of the verified native source scene."""
from pathlib import Path
import json,copy,math,heapq,hashlib,time,xml.etree.ElementTree as ET
P=Path(__file__).resolve().parent
L=json.loads((P/'source-layout.json').read_text())
S=json.loads((P/'source-scene.json').read_text())
E=copy.deepcopy(S['elements']); D={e['id']:e for e in E}
G={g['key']:g for g in L['groups']}; LF={v['ref']:v for v in L['leaves']}
BT={e['containerId']:e['id'] for e in E if e['type']=='text' and e.get('containerId')}
B={}; placed=set(); layouts={}; text_boxes={}
LEFT=140; CW=2400; INNER=LEFT+24; IW=CW-48

def clean(t):return t.replace('\\n','\n').replace('\n','')
def wrap(t,width,font):
    out=[]
    for para in t.replace('\\n','\n').split('\n'):
        line='';n=0
        for c in para:
            k=font*(1 if ord(c)>255 else (0.28 if c in ' .,:;ijlI' else 0.56))
            if line and n+k>width:out.append(line);line='';n=0
            line+=c;n+=k
        out.append(line)
    return '\n'.join(out)
def metrics(t,f):
    return max((sum(f*(1 if ord(c)>255 else (0.28 if c in ' .,:;ijlI' else 0.56)) for c in x) for x in t.split('\n')),default=1),len(t.split('\n'))*f*1.15

def txt(id,text,x,y,w,h,font=22,align='center',color='#202020',container=None):
    e=D[id]; t=wrap(text,w,font); tw,th=metrics(t,font)
    e.update(text=t,originalText=t,rawText=t,x=x+(w-tw)/2 if align=='center' else x,y=y+(h-th)/2,width=tw,height=th,fontSize=font,fontFamily=2,textAlign=align,verticalAlign='middle',autoResize=True,lineHeight=1.15,roughness=0,strokeColor=color,containerId=container)
    e.pop('labelPosition',None); placed.add(id);text_boxes[id]=(x,y,w,h)
    return th

def box(id,x,y,w,h,role=None,text=None,font=22,fill=None):
    e=D[id];e.update(x=x,y=y,width=w,height=h,angle=0,roughness=0,strokeColor='#555555',strokeWidth=1.15,backgroundColor=fill or '#ffffff',roundness={'type':3} if role=='leaf' else None)
    if role in ['chapter-body','group-body']:e.update(backgroundColor='transparent',strokeColor='#b5b5b5' if role=='group-body' else '#777777',strokeWidth=0.8)
    if role in ['chapter-header','group-header','summary-bar']:e.update(backgroundColor='#f5f5f5',strokeColor='#555555',strokeWidth=1.15)
    B[id]={'x':x,'y':y,'width':w,'height':h};placed.add(id)
    if id in BT:
        tid=BT[id];s=text if text is not None else clean(D[tid]['originalText'])
        txt(tid,s,x+10,y+5,w-20,h-10,font,container=id)
    return B[id]

# Explicit rows preserve original concepts; only wrapping/orientation changes.
ROWS={
 '2.1':[[0,1,2,3],[4]], '2.2':[[0,1,2,3],[4],[5]],
 '2.3':[[0,1,2,3,4]], '2.4':[[0,1],[2,3],[4]],
 '3.3.1':[[0,1,2,3,4],[5],[6]],
 '3.3.2':[[0,1,2],[3],[4,5]],
 '3.3.3':[[0,1],[2,3]],
 '3.4.1':[[0,1,2,3],[4,5,6]],
 '3.4.2':[[0,1],[2,3,4],[5,6]],
 '4.1':[[0,1],[2],[3]], '4.2':[[0,1,2],[3,4,5]],
 '4.3':[[0,1],[2,3],[4,5]], '4.4':[[0,1,2,3],[4]],
 '6.2':[[0,1,2],[3]],
}
# 5.4 remains a compact left-to-right explanation chain, not a forced vertical column.

def group(key,x,y,w,h):
    g=G[key];box(g['bodyId'],x,y,w,h,'group-body');box(g['headId'],x,y,w,66,'group-header',g['title'],22)
    layouts[key]={'x':x,'y':y,'width':w,'height':h}
    leaves=[v for v in L['leaves'] if v['group']==key]
    rows=ROWS.get(key,[list(range(len(leaves)))])
    note=next((a for a in L['annotations'] if a['owner']==key),None)
    noteh=64 if note else 0
    top=y+94; bottom=y+h-18-noteh
    if key=='5.4':
        cols=[[LF[r] for r in cohort] for cohort in g['cohorts']]
        gap=68; widths=[max(54*len(c)+24*(len(c)-1),110) for c in cols]
        total=sum(widths)+gap*(len(cols)-1)
        cur=x+(w-total)/2
        for col,cw in zip(cols,widths):
            sh=max(190,len(clean(col[0]['text']))*25.3+24)
            cur2=cur+(cw-54*len(col)-24*(len(col)-1))/2
            for lf in col:
                th=len(lf['text'])*25.3+24
                box(lf['id'],cur2,top,54,max(220,th),'leaf','\n'.join(lf['text']),22)
                cur2+=78
            cur+=cw+gap
    else:
        specs=[]
        for ri,row in enumerate(rows):
            horiz=(ri>0 and key not in ['4.2','3.4.2']) or key in ['4.3','3.1','3.2'] or (ri==2 and key=='3.4.2')
            gap=24 if horiz else (70 if len(rows)==1 and len(row)<4 else 28)
            # Explicit horizontal row cards wrap rather than shrinking font.
            cw=min(250,(w-48-gap*(len(row)-1))/max(1,len(row))) if horiz else 54
            rh=max((metrics(wrap(leaves[i]['text'],cw-20,22),22)[1]+24 if horiz else len(leaves[i]['text'])*25.3+24 for i in row),default=0)
            specs.append((row,horiz,gap,cw,rh))
        avail=bottom-top; total=sum(s[4] for s in specs)+58*(len(specs)-1)
        if total>avail+1:raise ValueError((key,'height',total,avail))
        # align first row across chapter, retain a compact local stack
        cur=top
        for row,horiz,gap,cw,rh in specs:
            xx=x+(w-(len(row)*cw+(len(row)-1)*gap))/2
            for i in row:
                lf=leaves[i];text=lf['text'] if horiz else '\n'.join(lf['text'])
                box(lf['id'],xx,cur,cw,rh,'leaf',text,22);xx+=cw+gap
            cur+=rh+58
    if note:
        txt(note['id'],clean(note['text']),x+14,y+h-76,w-28,64,16,'left','#565656')

Y=230; chap={}
# Common row grids; section gutters reserve routes rather than scattered whitespace.
def chapter(n,rows):
    global Y
    start=Y; cc=L['chapters'][n-1];yy=start+82
    for keys,widths,hh,gap in rows:
        xx=INNER
        for key,ww in zip(keys,widths):group(key,xx,yy,ww,hh);xx+=ww+gap
        yy+=hh+80
    end=yy+52
    box(cc['bodyId'],LEFT,start,CW,end-start,'chapter-body')
    box(cc['headId'],LEFT,start,CW,54,'chapter-header',font=28)
    sb=L['summaryBars'][n-1];box(sb['id'],INNER,end-62,IW,44,'summary-bar',sb['text'],20)
    chap[n]=(start,end);Y=end+42

chapter(1,[([f'1.{i}' for i in range(1,7)],[352]*6,400,48)])
chapter(2,[([f'2.{i}' for i in range(1,5)],[528]*4,600,80)])
# Chapter 3 uses a shared top band and a dense 3+2 method matrix.
start=Y;yy=start+82
group('3.1',INNER,yy,670,190);group('3.2',INNER+750,yy,IW-750,190)
yy+=270
for key,xx,ww in [('3.3',INNER,1372),('3.4',INNER+1452,900)]:
    g=G[key];box(g['bodyId'],xx,yy,ww,896,'group-body');box(g['headId'],xx,yy,ww,54,'group-header',g['title'],24);layouts[key]={'x':xx,'y':yy,'width':ww,'height':896}
for k,i in [('3.3.1',0),('3.3.2',1),('3.3.3',2)]:group(k,INNER+18+i*448,yy+76,426,760)
for k,i in [('3.4.1',0),('3.4.2',1)]:group(k,INNER+1470+i*442,yy+76,422,760)
end=yy+1006
cc=L['chapters'][2];box(cc['bodyId'],LEFT,start,CW,end-start,'chapter-body');box(cc['headId'],LEFT,start,CW,54,'chapter-header',font=28)
sb=L['summaryBars'][2];box(sb['id'],INNER,end-62,IW,44,'summary-bar',sb['text'],20);chap[3]=(start,end);Y=end+42
chapter(4,[([f'4.{i}' for i in range(1,5)],[528]*4,620,80)])
chapter(5,[(['5.1','5.2','5.3'],[730,730,732],360,80),(['5.4','5.5'],[1660,612],420,80)])
chapter(6,[(['6.1','6.2','6.3'],[730,730,732],450,80)])
# Left chapter markers; right aligned stage rails.
markers=[k for k,v in L['roles'].items() if v=='chapter-marker']
for n,id in enumerate(markers,1):
    a,b=chap[n];box(id,28,(a+b)/2-110,84,220,'marker',D[BT[id]]['originalText'],22)
stages=[k for k,v in L['roles'].items() if v=='stage-marker']
for id,(a,b) in zip(stages,[(chap[1][0],chap[2][1]),chap[3],(chap[4][0],chap[5][1]),chap[6]]):
    box(id,2580,a,76,b-a,'marker',D[BT[id]]['originalText'],22)
root=[a for a in L['annotations'] if a['owner']=='root']
for a in root:
    if a['id']=='LwFcT23X':txt(a['id'],a['text'],LEFT,20,CW,54,34)
    elif a['id']=='M9qJYMOs':txt(a['id'],a['text'],LEFT,82,CW,30,22)
    elif a['id']=='X9VHc5OW':txt(a['id'],a['text'],LEFT+24,126,CW-48,86,18,'left','#555555')
    else:txt(a['id'],a['text'],LEFT,Y,CW,64,18,'center','#555555')

# Compact orthogonal routes. All semantic endpoint IDs are preserved.
leafids={v['id'] for v in L['leaves']};headids={g['headId'] for g in L['groups']}
node_to_group={v['id']:v['group'] for v in L['leaves']}
node_to_group.update({g['bodyId']:g['key'] for g in L['groups']})

def rect(id,pad=0):
    b=B[id];return (b['x']-pad,b['y']-pad,b['x']+b['width']+pad,b['y']+b['height']+pad)
def mid(r):return ((r[0]+r[2])/2,(r[1]+r[3])/2)
def hits(a,b,r):
    eps=.01
    if a[0]==b[0]:return r[0]+eps<a[0]<r[2]-eps and max(min(a[1],b[1]),r[1]+eps)<min(max(a[1],b[1]),r[3]-eps)
    if a[1]==b[1]:return r[1]+eps<a[1]<r[3]-eps and max(min(a[0],b[0]),r[0]+eps)<min(max(a[0],b[0]),r[2]-eps)
    return True

def astar(a,b,obs,region):
    # visibility grid made only from local obstacle corners and endpoint lines
    xs=sorted(set([a[0],b[0],region[0],region[2]]+[v for r in obs for v in (r[0],r[2])]))
    ys=sorted(set([a[1],b[1],region[1],region[3]]+[v for r in obs for v in (r[1],r[3])]))
    start=(xs.index(a[0]),ys.index(a[1]),-1);target=(xs.index(b[0]),ys.index(b[1]));dist={start:0};prev={};hq=[(0,0,start)]
    while hq:
        _,cost,u=heapq.heappop(hq)
        if cost!=dist.get(u):continue
        ix,iy,old=u
        if (ix,iy)==target:
            route=[]
            while u in prev:route.append((xs[u[0]],ys[u[1]]));u=prev[u]
            route.append(a);return route[::-1]
        pp=(xs[ix],ys[iy])
        for dx,dy,dd in [(1,0,0),(-1,0,0),(0,1,1),(0,-1,1)]:
            nx,ny=ix+dx,iy+dy
            if not(0<=nx<len(xs) and 0<=ny<len(ys)):continue
            qq=(xs[nx],ys[ny])
            if any(hits(pp,qq,r) for r in obs):continue
            nc=cost+abs(pp[0]-qq[0])+abs(pp[1]-qq[1])+(30 if old not in [-1,dd] else 0)
            v=(nx,ny,dd)
            if nc<dist.get(v,1e99):dist[v]=nc;prev[v]=u;heapq.heappush(hq,(nc+abs(qq[0]-b[0])+abs(qq[1]-b[1]),nc,v))
    return None

def simplify(points):
    r=[]
    for q in points:
        if r and q==r[-1]:continue
        if len(r)>1 and ((q[0]==r[-1][0]==r[-2][0]) or (q[1]==r[-1][1]==r[-2][1])):r[-1]=q
        else:r.append(q)
    return r

routing=[]; label_occupied=[]; failed=[]
for ei,ed in enumerate(L['edges']):
    id=ed['id'];a=ed['fromId'];b=ed['toId'];ra,rb=rect(a),rect(b);ca,cb=mid(ra),mid(rb)
    ga,gb=node_to_group.get(a),node_to_group.get(b)
    same=ga==gb and ga is not None
    # Route containers around other containers; leaf relations within their shared section.
    if ed['kind']=='chapter':
        points=[(LEFT+CW/2,ra[3]),(LEFT+CW/2,rb[1])];sides=('bottom','top')
    else:
        obstacleids=set(leafids|headids)
        if not same:obstacleids|={g['bodyId'] for g in L['groups'] if not (g['key']==ga or g['key']==gb or (ga or '').startswith(g['key']+'.') or (gb or '').startswith(g['key']+'.'))}
        obstacleids-={a,b}
        # exclude descendant cards of container source/target, but route only from its boundary
        if a not in leafids:obstacleids={k for k in obstacleids if not (rect(k)[0]>=ra[0] and rect(k)[2]<=ra[2] and rect(k)[1]>=ra[1] and rect(k)[3]<=ra[3])}
        if b not in leafids:obstacleids={k for k in obstacleids if not (rect(k)[0]>=rb[0] and rect(k)[2]<=rb[2] and rect(k)[1]>=rb[1] and rect(k)[3]<=rb[3])}
        if same:
            gg=layouts[ga];reg=(gg['x']+8,gg['y']+74,gg['x']+gg['width']-8,gg['y']+gg['height']-84)
        else:
            n=int((ga or gb or '1')[0]);aa,bb=chap[n];reg=(LEFT+8,aa+66,LEFT+CW-8,bb-72)
        obs=[rect(k,7) for k in obstacleids if rect(k)[2]>=reg[0] and rect(k)[0]<=reg[2] and rect(k)[3]>=reg[1] and rect(k)[1]<=reg[3]]
        # Only include obstacles inside region; large parent containers aren't barriers.
        obs=[r for r in obs if not(r[0]<reg[0] and r[2]>reg[2])]
        if abs(ca[1]-cb[1])<30 and ra[2]<rb[0]:prefs=[('right','left'),('bottom','bottom'),('top','top')]
        elif abs(ca[1]-cb[1])<30 and rb[2]<ra[0]:prefs=[('left','right'),('bottom','bottom'),('top','top')]
        elif ca[1]<cb[1]:prefs=[('bottom','top'),('right','right'),('left','left')]
        else:prefs=[('top','bottom'),('right','right'),('left','left')]
        if ed['kind']=='feedback':prefs=[('bottom','bottom'),('right','right'),('left','left')]+prefs
        def port(r,side):return {'left':(r[0],(r[1]+r[3])/2),'right':(r[2],(r[1]+r[3])/2),'top':((r[0]+r[2])/2,r[1]),'bottom':((r[0]+r[2])/2,r[3])}[side]
        options=[]
        for si,ti in prefs:
            p,q=port(ra,si),port(rb,ti)
            # simple doglegs first; visibility grid is the fallback.
            trials=[[p,q]] if p[0]==q[0] or p[1]==q[1] else [[p,(p[0],q[1]),q],[p,(q[0],p[1]),q]]
            trials += [[p,(p[0],(p[1]+q[1])/2),(q[0],(p[1]+q[1])/2),q],[p,((p[0]+q[0])/2,p[1]),((p[0]+q[0])/2,q[1]),q]]
            good=[t for t in trials if not any(hits(u,v,r) for u,v in zip(t,t[1:]) for r in obs+[ra,rb])]
            if good:rt=min(good,key=lambda t:sum(abs(u[0]-v[0])+abs(u[1]-v[1]) for u,v in zip(t,t[1:])))
            else:rt=astar(p,q,obs+[ra,rb],reg)
            if rt:
                rt=simplify(rt);cost=sum(abs(u[0]-v[0])+abs(u[1]-v[1]) for u,v in zip(rt,rt[1:]))+30*len(rt)
                options.append((cost,rt,(si,ti)))
        if not options:failed.append(id);points=[ca,cb];sides=('right','left')
        else:_,points,sides=min(options,key=lambda z:z[0])
    ar=D[id];ar.update(x=points[0][0],y=points[0][1],width=max(p[0] for p in points)-min(p[0] for p in points),height=max(p[1] for p in points)-min(p[1] for p in points),points=[[p[0]-points[0][0],p[1]-points[0][1]] for p in points],strokeColor='#666666' if ed['kind']!='feedback' else '#888888',strokeWidth=1.15 if ed['kind']!='chapter' else 2.4,roughness=0,roundness=None)
    anchors={'left':[0,.5],'right':[1,.5],'top':[.5,0],'bottom':[.5,1]}
    ar['startBinding']={'elementId':a,'mode':'orbit','fixedPoint':anchors[sides[0]]};ar['endBinding']={'elementId':b,'mode':'orbit','fixedPoint':anchors[sides[1]]}
    placed.add(id)
    # Arrow captions become grouped movable labels so routing cannot force text onto cards.
    if id in BT:
        tid=BT[id];text=clean(D[tid]['originalText']);f=14;tw,th=metrics(text,f)
        candidates=[]
        for u,v in zip(points,points[1:]):
            if u==v:continue
            for frac in [.5,.3,.7]:
                cx=u[0]+(v[0]-u[0])*frac;cy=u[1]+(v[1]-u[1])*frac
                for ox,oy in ([(0,-th/2-4),(0,th/2+4)] if u[1]==v[1] else [(tw/2+5,0),(-tw/2-5,0)]):
                    rr=(cx+ox-tw/2,cy+oy-th/2,cx+ox+tw/2,cy+oy+th/2)
                    def overlap(r,s):return max(r[0],s[0])<min(r[2],s[2]) and max(r[1],s[1])<min(r[3],s[3])
                    ob=[rect(k,2) for k in leafids|headids]+label_occupied
                    bad=sum(overlap(rr,r) for r in ob)
                    candidates.append((bad,abs(frac-.5),rr))
        bestbad,_,rr=min(candidates,key=lambda z:(z[0],z[1]))
        if bestbad:
            # Keep captions near their line, but allow explicit short wrapping
            # and a free neighbouring pocket when a narrow gutter cannot fit.
            alternatives=[]
            for ctext in [text,wrap(text,56,f),wrap(text,28,f)]:
                ww,hh=metrics(ctext,f)
                for u,v in zip(points,points[1:]):
                    for frac in [.5,.25,.75]:
                        cx=u[0]+(v[0]-u[0])*frac;cy=u[1]+(v[1]-u[1])*frac
                        for dx in range(-84,85,14):
                            for dy in range(-84,85,14):
                                if not dx and not dy:continue
                                r=(cx+dx-ww/2,cy+dy-hh/2,cx+dx+ww/2,cy+dy+hh/2)
                                if not any(overlap(r,o) for o in ob):
                                    alternatives.append((abs(dx)+abs(dy)+8*(len(ctext.split('\n'))-1),r,ctext,ww,hh))
            if not alternatives:raise ValueError(('caption has no clear pocket',id,text))
            _,rr,text,tw,th=min(alternatives,key=lambda z:z[0])
        txt(tid,text,rr[0],rr[1],tw,th,f,color='#666666');D[tid]['containerId']=None
        gid='compact-edge-'+id;ar['groupIds']=[gid];D[tid]['groupIds']=[gid];ar['boundElements']=[v for v in ar.get('boundElements',[]) if v['id']!=tid]
        label_occupied.append(rr)
    routing.append({**ed,'points':points,'sides':sides})

missing=set(D)-placed
if missing:raise ValueError(('unplaced',[(k,D[k].get('text'),D[k]['type']) for k in missing]))
if failed:raise ValueError(('unroutable',failed))
# Native groups allow each section's cards to move as a unit without flattening.
for e in E:
    e['version']=e.get('version',1)+1;e['versionNonce']=int(hashlib.sha256((e['id']+'compact').encode()).hexdigest()[:7],16);e['updated']=int(time.time()*1000)
# Validate content identity independent of explicit wrapping.
for old in S['elements']:
    if old['type']=='text':assert clean(old['originalText'])==clean(D[old['id']]['originalText']),old['id']
for ed in L['edges']:
    ar=D[ed['id']];assert ar['startBinding']['elementId']==ed['fromId'] and ar['endBinding']['elementId']==ed['toId']
scene={'type':'excalidraw','version':2,'source':'Obsidian Excalidraw native scene; layout-only compact transformation','elements':E,'appState':{'viewBackgroundColor':'#ffffff','gridSize':None},'files':{}}
(P/'compact-template.excalidraw').write_text(json.dumps(scene,ensure_ascii=False,indent=2))
layout={**L,'width':2680,'height':Y+80,'boxes':B,'groupBounds':layouts,'chapterBounds':chap,'edges':routing,'sourceRevision':S['revision'],'layoutMode':'reference-aligned compact chapter bands','expectedText':{e['id']:e['originalText'] for e in E if e['type']=='text'}}
(P/'compact-layout.json').write_text(json.dumps(layout,ensure_ascii=False,indent=2))
# Editable draw.io uses the same geometry and IDs as the native transformation.
mx=ET.Element('mxfile',host='app.diagrams.net',version='26.0.0');dia=ET.SubElement(mx,'diagram',name='紧凑分层研究框架',id='compact-framework');mod=ET.SubElement(dia,'mxGraphModel',page='0',grid='1',gridSize='10',background='#ffffff');root=ET.SubElement(mod,'root');ET.SubElement(root,'mxCell',id='0');ET.SubElement(root,'mxCell',id='1',parent='0')
# layer ordering matches native source (backgrounds then connectors then content)
for e in E:
    id=e['id'];typ=e['type'];style='html=1;whiteSpace=wrap;fontFamily=Arial;'
    at={'id':id,'parent':'1'}
    if typ=='rectangle':
        col=e['strokeColor'];fill=e['backgroundColor'];fill='none' if fill=='transparent' else fill
        style+=f'rounded={1 if e.get("roundness") else 0};arcSize=10;strokeColor={col};fillColor={fill};strokeWidth={e["strokeWidth"]};'
        at.update(vertex='1',value='',style=style);cell=ET.SubElement(root,'mxCell',at);ET.SubElement(cell,'mxGeometry',x=str(e['x']),y=str(e['y']),width=str(e['width']),height=str(e['height']),attrib={'as':'geometry'})
    elif typ=='text':
        style+=f'fontSize={e["fontSize"]};fontColor={e["strokeColor"]};align={e["textAlign"]};verticalAlign=middle;strokeColor=none;fillColor=none;spacing=0;'
        at.update(vertex='1',value=e['text'].replace('\n','<br>'),style=style);cell=ET.SubElement(root,'mxCell',at);ET.SubElement(cell,'mxGeometry',x=str(e['x']),y=str(e['y']),width=str(e['width']+2),height=str(e['height']+2),attrib={'as':'geometry'})
    elif typ=='arrow':
        ed=next(a for a in routing if a['id']==id);ss,ts=ed['sides'];sx,sy=anchors[ss];tx,ty=anchors[ts]
        style+=f'noEdgeStyle=1;rounded=0;orthogonalLoop=1;jettySize=auto;endArrow=block;endFill=1;endSize=7;strokeWidth={e["strokeWidth"]};strokeColor={e["strokeColor"]};exitX={sx};exitY={sy};entryX={tx};entryY={ty};exitPerimeter=0;entryPerimeter=0;'
        if e.get('strokeStyle')=='dashed':style+='dashed=1;'
        at.update(edge='1',source=ed['fromId'],target=ed['toId'],value='',style=style);cell=ET.SubElement(root,'mxCell',at);geom=ET.SubElement(cell,'mxGeometry',relative='1',attrib={'as':'geometry'});arr=ET.SubElement(geom,'Array',attrib={'as':'points'})
        for px,py in ed['points'][1:-1]:ET.SubElement(arr,'mxPoint',x=str(px),y=str(py))
# Real draw.io parent/child containment, with coordinates relative to parents.
parentmap={}
for n,ch in enumerate(L['chapters'],1):
    parentmap[ch['headId']]=ch['bodyId']
    parentmap[L['summaryBars'][n-1]['id']]=ch['bodyId']
for key,g in G.items():
    parentkey=key.rsplit('.',1)[0]
    parentmap[g['bodyId']]=G[parentkey]['bodyId'] if parentkey in G else L['chapters'][int(key[0])-1]['bodyId']
    parentmap[g['headId']]=g['bodyId']
for lf in L['leaves']:parentmap[lf['id']]=G[lf['group']]['bodyId']
for a in L['annotations']:
    if a['owner'] in G:parentmap[a['id']]=G[a['owner']]['bodyId']
for e in E:
    if e['type']=='text' and e.get('containerId'):parentmap[e['id']]=e['containerId']
for cell in root:
    id=cell.get('id')
    if id in parentmap:
        parent=parentmap[id];cell.set('parent',parent);geom=cell.find('mxGeometry')
        geom.set('x',str(D[id]['x']-D[parent]['x']));geom.set('y',str(D[id]['y']-D[parent]['y']))
    if id in B and L['roles'].get(id) in ['group-body','chapter-body']:
        cell.set('style',cell.get('style')+'container=1;pointerEvents=0;collapsible=0;')
ET.indent(mx);ET.ElementTree(mx).write(P/'紧凑分层研究框架.drawio',encoding='UTF-8',xml_declaration=True)
print(json.dumps({'elements':len(E),'texts':sum(e['type']=='text' for e in E),'arrows':len(routing),'terminalConcepts':len(LF),'bounds':[2680,Y+80],'chapters':chap,'allOriginalIds':True,'allTextPreserved':True},ensure_ascii=False))
