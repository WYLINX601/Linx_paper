"""Content-fitted layout; original native identities and relations remain intact."""
from pathlib import Path
import json,copy,math,heapq,hashlib,time,xml.etree.ElementTree as ET
P=Path(__file__).resolve().parent
L=json.loads((P/'source-layout.json').read_text());S=json.loads((P/'source-scene.json').read_text())
E=copy.deepcopy(S['elements']);D={e['id']:e for e in E}
live={e['id']:e for e in json.loads((P/'source-live.json').read_text())['elements']}
assert set(D)==set(live)
for id,e in D.items():
 for field in set(e)|set(live[id]):
  a,b=e.get(field),live[id].get(field)
  if a==b:continue
  if field in ['startBinding','endBinding']:
   assert a['elementId']==b['elementId'] and a['mode']==b['mode']
   assert all(abs(x-y)<.001 for x,y in zip(a['fixedPoint'],b['fixedPoint']))
  elif e['type']=='arrow' and field in ['x','y','width','height','points','version','versionNonce','updated']:continue
  elif field in ['version','versionNonce','updated']:continue
  elif isinstance(a,(int,float)) and isinstance(b,(int,float)) and abs(a-b)<1e-8:continue
  else:raise AssertionError((id,field,a,b))
# The clean live view has native binding-normalized routes; those routes are
# explicitly being replaced. Non-arrow content, positions and identities match.
for id,e in D.items():
 for f in ['version','versionNonce','updated']:
  if f in live[id]:e[f]=live[id][f]
G={g['key']:g for g in L['groups']};LF={v['ref']:v for v in L['leaves']}
BT={e['containerId']:e['id'] for e in E if e['type']=='text' and e.get('containerId')}
for e in E:
 if e['type']=='text':
  for g in e.get('groupIds',[]):
   if g.startswith('compact-edge-'):BT[g.removeprefix('compact-edge-')]=e['id']
B={};placed=set();layouts={};text_boxes={};chap={}
LEFT=112;CW=1940;INNER=LEFT+16;IW=CW-32

def clean(t):return t.replace('\\n','\n').replace('\n','')
def metrics(t,f):
 return max((sum(f*(1 if ord(c)>255 else (.28 if c in ' .,:;ijlI' else .56)) for c in x) for x in t.split('\n')),default=1),len(t.split('\n'))*f*1.15
def wrap(t,w,f):
 out=[]
 for para in t.replace('\\n','\n').split('\n'):
  line=''
  for c in para:
   if line and metrics(line+c,f)[0]>w:out.append(line);line=''
   line+=c
  out.append(line)
 return '\n'.join(out)
def txt(id,text,x,y,w,h,font=22,align='center',color='#202020',container=None):
 t=wrap(text,w,font);tw,th=metrics(t,font);e=D[id]
 e.update(text=t,originalText=t,rawText=t,x=x+(w-tw)/2 if align=='center' else x,y=y+(h-th)/2,width=tw,height=th,fontSize=font,fontFamily=2,textAlign=align,verticalAlign='middle',autoResize=True,lineHeight=1.15,roughness=0,strokeColor=color,containerId=container)
 e.pop('labelPosition',None);placed.add(id);text_boxes[id]=(x,y,w,h)
def box(id,x,y,w,h,role=None,text=None,font=22):
 e=D[id];e.update(x=x,y=y,width=w,height=h,angle=0,roughness=0,strokeColor='#555555',strokeWidth=1.15,backgroundColor='#ffffff',roundness={'type':3} if role=='leaf' else None)
 if role in ['chapter-body','group-body']:e.update(backgroundColor='transparent',strokeColor='#b5b5b5' if role=='group-body' else '#777777',strokeWidth=.8)
 if role in ['chapter-header','group-header','summary-bar']:e.update(backgroundColor='#f5f5f5')
 B[id]={'x':x,'y':y,'width':w,'height':h};placed.add(id)
 if id in BT:txt(BT[id],text if text is not None else clean(D[BT[id]]['originalText']),x+8,y+5,w-16,h-10,font,container=id)
 return B[id]

ROWS={'2.1':[[0,1,2,3],[4]],'2.2':[[0,1,2,3],[4,5]],'2.3':[[0,1,2,3,4]],'2.4':[[0,1],[2,3],[4]],'3.3.1':[[0,1,2,3,4],[5,6]],'3.3.2':[[0,1,2],[3],[4,5]],'3.3.3':[[0,1],[2,3]],'3.4.1':[[0,1,2,3],[4,5,6]],'3.4.2':[[0,1],[2,3,4],[5,6]],'4.1':[[0,1],[2,3]],'4.2':[[0,1,2],[3,4,5]],'4.3':[[0,1],[2,3],[4,5]],'4.4':[[0,1,2,3],[4]],'6.2':[[0,1,2],[3]]}

def group(key,x,y,w):
 g=G[key];leaves=[v for v in L['leaves'] if v['group']==key];rows=ROWS.get(key,[list(range(len(leaves)))])
 note=next((a for a in L['annotations'] if a['owner']==key),None)
 hh=max(44,metrics(wrap(g['title'],w-16,22),22)[1]+12)
 top=y+hh+18;cur=top
 specs=[]
 if key=='5.4':
  cohorts=[[LF[r] for r in c] for c in g['cohorts']];gap=42;cw=50;smallgap=15
  widths=[len(c)*cw+(len(c)-1)*smallgap for c in cohorts];total=sum(widths)+gap*(len(widths)-1)
  assert total<=w-24,(key,total,w)
  xx=x+(w-total)/2;rh=max(len(v['text'])*25.3+18 for c in cohorts for v in c)
  for c,ww in zip(cohorts,widths):
   for v in c:box(v['id'],xx,cur,cw,rh,'leaf','\n'.join(v['text']));xx+=cw+smallgap
   xx+=gap-smallgap
  cur+=rh
 else:
  for ri,row in enumerate(rows):
   horiz=(ri>0 or key in ['1.2','1.3','1.6','2.1','2.2','2.4','3.1','3.2','3.3.2','3.3.3','3.4.2','4.1','4.2','4.3','4.4','5.1','5.2','5.3','5.5','6.1','6.2','6.3'])
   gap=24 if horiz else 20
   if horiz:
    # Width follows content, capped by the row, rather than empty equal columns.
    maxw=(w-24-gap*(len(row)-1))/len(row)
    widths=[min(maxw,metrics(leaves[i]['text'],22)[0]+20) for i in row]
    rh=max(metrics(wrap(leaves[i]['text'],ww-16,22),22)[1]+18 for i,ww in zip(row,widths))
   else:
    widths=[50]*len(row);rh=max(len(leaves[i]['text'])*25.3+18 for i in row)
   total=sum(widths)+gap*(len(row)-1);assert total<=w-16,(key,total,w)
   xx=x+(w-total)/2
   for i,ww in zip(row,widths):
    v=leaves[i];box(v['id'],xx,cur,ww,rh,'leaf',v['text'] if horiz else '\n'.join(v['text']));xx+=ww+gap
   cur+=rh+(32 if ri<len(rows)-1 else 0)
 # Notes follow the actual last row instead of being pinned far below it.
 if note:
  nh=metrics(wrap(clean(note['text']),w-24,16),16)[1]
  cur+=30;txt(note['id'],clean(note['text']),x+12,cur,w-24,nh,16,'left','#565656');cur+=nh
 h=cur-y+16
 box(g['bodyId'],x,y,w,h,'group-body');box(g['headId'],x,y,w,hh,'group-header',g['title'])
 layouts[key]={'x':x,'y':y,'width':w,'height':h};return h

Y=196

def finishchapter(n,start,bottom):
 global Y
 cc=L['chapters'][n-1];end=bottom+68
 box(cc['bodyId'],LEFT,start,CW,end-start,'chapter-body');box(cc['headId'],LEFT,start,CW,46,'chapter-header',font=28)
 sb=L['summaryBars'][n-1];box(sb['id'],INNER,end-48,IW,36,'summary-bar',sb['text'],20)
 chap[n]=(start,end);Y=end+28

def row(keys,widths,y,gap=40):
 assert abs(sum(widths)+gap*(len(widths)-1)-IW)<.01,(keys,widths,IW)
 xx=INNER;bottom=y
 for key,w in zip(keys,widths):bottom=max(bottom,y+group(key,xx,y,w));xx+=w+gap
 return bottom

def chapter(n,keys,widths):
 start=Y;bottom=row(keys,widths,start+62);finishchapter(n,start,bottom)

chapter(1,[f'1.{i}' for i in range(1,7)],[190,322,286,318,264,328])
chapter(2,[f'2.{i}' for i in range(1,5)],[442,464,434,448])
start=Y;yy=start+62
bottom=row(['3.1','3.2'],[720,1148],yy);yy=bottom+48
parent_specs=[('3.3',INNER,1118,['3.3.1','3.3.2','3.3.3'],[354,346,338]),('3.4',INNER+1158,750,['3.4.1','3.4.2'],[348,346])]
bs=[]
for key,x,w,keys,widths in parent_specs:
 g=G[key];xx=x+12;bottom=yy+48
 for ck,cw in zip(keys,widths):bottom=max(bottom,yy+64+group(ck,xx,yy+64,cw));xx+=cw+28
 assert xx-28<=x+w-12+.01,(key,xx,x+w)
 h=bottom-yy+22;box(g['bodyId'],x,yy,w,h,'group-body');box(g['headId'],x,yy,w,46,'group-header',g['title'],24);layouts[key]={'x':x,'y':yy,'width':w,'height':h};bs.append(bottom+22)
finishchapter(3,start,max(bs))
chapter(4,[f'4.{i}' for i in range(1,5)],[416,472,458,442])
start=Y;bottom=row(['5.1','5.2','5.3'],[608,608,612],start+62)
bottom=row(['5.4','5.5'],[1270,598],bottom+44);finishchapter(5,start,bottom)
chapter(6,['6.1','6.2','6.3'],[608,696,524])
for n,id in enumerate([k for k,v in L['roles'].items() if v=='chapter-marker'],1):
 a,b=chap[n];box(id,20,(a+b)/2-92,68,184,'marker',D[BT[id]]['originalText'],22)
for id,(a,b) in zip([k for k,v in L['roles'].items() if v=='stage-marker'],[(chap[1][0],chap[2][1]),chap[3],(chap[4][0],chap[5][1]),chap[6]]):
 # Side tags no longer stretch into large empty rails.
 box(id,LEFT+CW+24,(a+b)/2-110,66,220,'marker',D[BT[id]]['originalText'],22)
for a in [a for a in L['annotations'] if a['owner']=='root']:
 if a['id']=='LwFcT23X':txt(a['id'],a['text'],LEFT,12,CW,44,34)
 elif a['id']=='M9qJYMOs':txt(a['id'],a['text'],LEFT,60,CW,28,22)
 elif a['id']=='X9VHc5OW':txt(a['id'],a['text'],LEFT+16,100,CW-32,80,18,'left','#555555')
 else:txt(a['id'],a['text'],LEFT,Y,CW,64,18,'center','#555555')

# Reuse the already-reviewed local orthogonal routing/export implementation.
# Only infrastructure is reused; input/current native scene is freshly read above.
base=(P/'routing_base.py').read_text()
start=base.index('# Compact orthogonal routes.')
tail=base[start:]
tail=tail.replace("reg=(gg['x']+8,gg['y']+74,gg['x']+gg['width']-8,gg['y']+gg['height']-84)","reg=(gg['x']+6,gg['y']+44,gg['x']+gg['width']-6,gg['y']+gg['height']-12)")
tail=tail.replace("reg=(LEFT+8,aa+66,LEFT+CW-8,bb-72)","reg=(LEFT+6,aa+48,LEFT+CW-6,bb-50)")
tail=tail.replace("ob=[rect(k,2) for k in leafids|headids]+label_occupied", "ob=[rect(k,2) for k in leafids|headids]+[(D[z]['x']-2,D[z]['y']-2,D[z]['x']+D[z]['width']+2,D[z]['y']+D[z]['height']+2) for z in placed if D[z]['type']=='text' and not any(g.startswith('compact-edge-') for g in D[z].get('groupIds',[]))]+label_occupied")
tail=tail.replace("'width':2680", "'width':LEFT+CW+100").replace("'bounds':[2680,Y+80]", "'bounds':[LEFT+CW+100,Y+80]")
tail=tail.replace("'layoutMode':'reference-aligned compact chapter bands'", "'layoutMode':'content-fitted dense modules; same font size'")
exec(compile(tail,'reviewed_orthogonal_routing_and_drawio_export','exec'),globals())
# Refresh all working geometry representations, not only the new boxes map.
for c in L['chapters']:
 c.update(B[c['bodyId']])
for g in L['groups']:g.update(B[g['bodyId']]);g['bounds']=B[g['bodyId']]
for leaf in L['leaves']:
 leaf.update(B[leaf['id']]);t=D[BT[leaf['id']]];leaf['orientation']='vertical' if max(map(len,t['text'].split('\n')))==1 else 'horizontal';leaf['renderedText']=t['text']
for a in L['annotations']:
 e=D[a['id']];a.update(x=e['x'],y=e['y'],width=e['width'],fontSize=e['fontSize'],text=e['text'])
layout.update(chapters=L['chapters'],groups=L['groups'],leaves=L['leaves'],annotations=L['annotations'],boundTextIds={e['containerId']:e['id'] for e in E if e['type']=='text' and e.get('containerId')})
layout['orientationCounts']={o:sum(lf['orientation']==o for lf in L['leaves']) for o in ['vertical','horizontal']}
(P/'compact-layout.json').write_text(json.dumps(layout,ensure_ascii=False,indent=2))
print('Content-fitted group sizes:',json.dumps({k:[v['width'],round(v['height'],1)] for k,v in layouts.items()}))
