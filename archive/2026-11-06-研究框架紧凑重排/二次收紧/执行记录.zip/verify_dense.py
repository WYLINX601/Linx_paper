from pathlib import Path
import json,itertools,hashlib,xml.etree.ElementTree as ET,html
from PIL import Image
P=Path(__file__).resolve().parent
L=json.loads((P/'compact-layout.json').read_text());S=json.loads((P/'candidate-scene.json').read_text());old=json.loads((P/'source-scene.json').read_text())
D={e['id']:e for e in S['elements']};OD={e['id']:e for e in old['elements']}
assert D.keys()==OD.keys()
for id,e in D.items():
 o=OD[id];assert e['type']==o['type']
 if e['type']=='text':assert e['originalText'].replace('\n','')==o['originalText'].replace('\n',''),id
 if e['type']=='arrow':
  for f in ['startBinding','endBinding']:assert e[f]['elementId']==o[f]['elementId']
  assert e['strokeStyle']==o['strokeStyle']
leaf={v['id'] for v in L['leaves']};head={v['headId'] for v in L['groups']}
def rect(e):return e['x'],e['y'],e['x']+e['width'],e['y']+e['height']
def over(a,b,p=.2):return min(a[2],b[2])-max(a[0],b[0])>p and min(a[3],b[3])-max(a[1],b[1])>p
def hit(a,b,r):
 if abs(a[0]-b[0])<.001:return r[0]+1<a[0]<r[2]-1 and max(min(a[1],b[1]),r[1]+1)<min(max(a[1],b[1]),r[3]-1)
 if abs(a[1]-b[1])<.001:return r[1]+1<a[1]<r[3]-1 and max(min(a[0],b[0]),r[0]+1)<min(max(a[0],b[0]),r[2]-1)
 return False
ov=[];lines=[];capt=[];bounds=[]
for a,b in itertools.combinations(leaf,2):
 if over(rect(D[a]),rect(D[b])):ov.append([a,b])
for e in D.values():
 if e['type']=='text' and e.get('containerId'):
  r=rect(e);c=rect(D[e['containerId']])
  if r[0]<c[0]-1 or r[1]<c[1]-1 or r[2]>c[2]+1 or r[3]>c[3]+1:bounds.append(e['id'])
 if e['type']=='arrow':
  pts=[(e['x']+p[0],e['y']+p[1]) for p in e['points']];ends={e['startBinding']['elementId'],e['endBinding']['elementId']}
  for id in leaf-ends:
   if any(hit(a,b,rect(D[id])) for a,b in zip(pts,pts[1:])):lines.append([e['id'],id])
texts=[e for e in D.values() if e['type']=='text' and any(g.startswith('compact-edge-') for g in e.get('groupIds',[]))]
for t in texts:
 for id in leaf|head:
  if over(rect(t),rect(D[id])):capt.append([t['id'],id,t['originalText']])
cc=[[a['id'],b['id']] for a,b in itertools.combinations(texts,2) if over(rect(a),rect(b))]
ann=[D[a['id']] for a in L['annotations']]
ca=[[a['id'],b['id']] for a in texts for b in ann if over(rect(a),rect(b))]
# Data identities and actual draw.io endpoints, not merely the SVG count.
cells={c.get('id'):c for c in ET.parse(P/'紧凑分层研究框架.drawio').iter('mxCell')};assert set(cells)-{'0','1'}==set(D)
for id,e in D.items():
 c=cells[id]
 if e['type']=='text':assert html.unescape(c.get('value','')).replace('<br>','\n')==e['text']
 if e['type']=='arrow':assert c.get('source')==e['startBinding']['elementId'] and c.get('target')==e['endBinding']['elementId']
im=Image.open(P/'native-preview.png');im.load();r=json.loads((P/'export-png-receipt.json').read_text())['response']['data'];sb=r['sceneToPreview']['sceneBounds'];sx=im.width/sb['width'];sy=im.height/sb['height']
for n,(y0,y1) in L['chapterBounds'].items():im.crop((0,max(0,int((y0-sb['y'])*sy)),im.width,min(im.height,int((y1-sb['y'])*sy)+2))).save(P/f'native-ch{n}.png')
# Measurable content density: terminal-card area / chapter content area.
# This is a geometric proxy, never claim it is the literal blank-pixel fraction.
def density(scene,layout):
 d={e['id']:e for e in scene['elements']}
 return sum(d[v['id']]['width']*d[v['id']]['height'] for v in layout['leaves'])/sum(d[c['bodyId']]['width']*d[c['bodyId']]['height'] for c in layout['chapters'])
oldlayout=json.loads((P/'source-layout.json').read_text())
prev={'width':2660,'height':5897.25}
res={'sourceRevision':old['revision'],'candidateRevision':S['revision'],'complete':S['pagesComplete'],'elements':len(D),'texts':sum(e['type']=='text' for e in D.values()),'terminalConcepts':len(leaf),'arrows':sum(e['type']=='arrow' for e in D.values()),'allIdsTypesTextAndEndpointsPreserved':True,'leafFontSizes':sorted({D[v['id']]['fontSize'] for id in leaf for v in D[id]['boundElements'] if v['type']=='text'}),'boundTextOverflows':bounds,'leafCardOverlaps':ov,'arrowsThroughLeaves':lines,'captionCardOverlaps':capt,'captionOverlaps':cc,'captionAnnotationOverlaps':ca,'actualExport':r,'previousExportBounds':prev,'canvasAreaReductionFromPreviousPercent':100*(1-sb['width']*sb['height']/(prev['width']*prev['height'])),'widthReductionPercent':100*(1-sb['width']/prev['width']),'heightReductionPercent':100*(1-sb['height']/prev['height']),'geometricDensityProxy':{'previous':density(old,oldlayout),'new':density(S,L),'definition':'sum terminal-card areas / sum chapter-frame areas; not blank pixel percentage'},'drawioNativeIdsTextEndpointsMatch':True,'imageElements':sum(e['type']=='image' for e in D.values())}
(P/'candidate-audit.json').write_text(json.dumps(res,ensure_ascii=False,indent=2));print(json.dumps(res,ensure_ascii=False))
assert not any([bounds,ov,lines,capt,cc,ca]),'Inspect collision details before publication'
