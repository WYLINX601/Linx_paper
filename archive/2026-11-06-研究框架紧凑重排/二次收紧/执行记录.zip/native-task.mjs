import {readFile, writeFile} from 'node:fs/promises';
import {invokeNative,readAll} from '/Users/wangyuelin/.hermes/profiles/academic/skills/obsidian-excalidraw-cli/scripts/native.mjs';
const base='/Users/wangyuelin/.hermes/profiles/academic/cache/scratch/framework-dense-20261106';
const common={vault:'Paper',executable:'/usr/local/bin/obsidian',stateDirectory:'/Users/wangyuelin/.hermes/profiles/academic/obsidian-excalidraw-state/Paper',timeoutMs:120000};
const [mode,arg,output,source]=process.argv.slice(2);
if(mode==='read'){
 const r=await readAll({...common,path:arg,source:source||'disk'});
 await writeFile(`${base}/${output}`,JSON.stringify(r,null,2));
 console.log(JSON.stringify({revision:r.revision,complete:r.pagesComplete,total:r.elements.length,file:output}));
}else{
 const req=JSON.parse(await readFile(`${base}/${arg}`,'utf8'));
 const r=await invokeNative({...common,command:mode,request:req});
 await writeFile(`${base}/${output}`,JSON.stringify(r,null,2));
 console.log(JSON.stringify(r.response));
}
