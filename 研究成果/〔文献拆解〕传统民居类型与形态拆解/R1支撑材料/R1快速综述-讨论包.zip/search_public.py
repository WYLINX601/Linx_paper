import concurrent.futures, datetime, json, re, urllib.parse, urllib.request
from pathlib import Path
BASE = Path(__file__).resolve().parent
QUERIES = ['vernacular dwelling typology morphology', 'traditional dwelling architectural typology spatial organization', 'Urban morphology as an emerging interdisciplinary field']

def run(source, query):
    if source == 'Crossref':
        url = 'https://api.crossref.org/works?' + urllib.parse.urlencode({'query.bibliographic': query, 'rows': 15})
    else:
        url = 'https://api.openalex.org/works?' + urllib.parse.urlencode({'search': query, 'per_page': 15})
    record = {'source': source, 'query': query, 'limit': 15, 'url': url, 'queried_at': datetime.datetime.now().astimezone().isoformat()}
    try:
        req = urllib.request.Request(url, headers={'User-Agent': 'AcademicRapidReview/1.0', 'Accept': 'application/json'})
        with urllib.request.urlopen(req, timeout=45) as response:
            raw = json.load(response)
        record['raw'] = raw
        entries = raw.get('message', {}).get('items', []) if source == 'Crossref' else raw.get('results', [])
        records = []
        for rank, w in enumerate(entries, 1):
            title = w.get('title', '')
            if isinstance(title, list): title = title[0] if title else ''
            doi = (w.get('DOI') or w.get('doi') or '').removeprefix('https://doi.org/')
            authors = w.get('author', []) if source == 'Crossref' else w.get('authorships', [])
            authors = [' '.join(filter(None, [a.get('given'), a.get('family')])) for a in authors] if source == 'Crossref' else [a.get('author', {}).get('display_name', '') for a in authors]
            records.append({'title': title, 'doi': doi, 'authors': authors, 'rank': rank, 'source': source, 'query': query, 'year': w.get('published', {}).get('date-parts', [[None]])[0][0] if source == 'Crossref' else w.get('publication_year'), 'url': w.get('URL') or w.get('doi') or w.get('id'), 'abstract': w.get('abstract') or '', 'locations': w.get('locations', []), 'links': w.get('link', [])})
        record.update(status='ok', returned=len(records), records=records, total_reported=raw.get('message', {}).get('total-results') if source == 'Crossref' else raw.get('meta', {}).get('count'))
    except Exception as exc:
        record.update(status='failed', error=str(exc), returned=None, records=[])
    return record

with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    results = list(pool.map(lambda sq: run(*sq), [(s,q) for s in ['Crossref','OpenAlex'] for q in QUERIES]))
(BASE / 'search-results-raw.json').write_text(json.dumps(results, ensure_ascii=False, indent=2))
unique = {}
for result in results:
    for r in result['records']:
        key = 'doi:' + r['doi'].lower() if r['doi'] else 'title:' + re.sub(r'\W+', '', r['title']).lower()
        if key not in unique: unique[key] = dict(r, occurrences=[])
        unique[key]['occurrences'].append({'source': r['source'], 'query': r['query'], 'rank': r['rank']})
summary = {'queries': [{k:r[k] for k in ['source','query','limit','status','returned'] } | ({'error':r['error']} if 'error' in r else {}) for r in results], 'retrieved_records':sum(len(r['records']) for r in results), 'unique_records':len(unique), 'note':'Rank-limited supplementary discovery; not exhaustive. DOI then normalized-title deduplication; report-level only.', 'records':list(unique.values())}
(BASE / 'search-results.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2))
print(json.dumps({k:v for k,v in summary.items() if k!='records'},ensure_ascii=False,indent=2))
for i,r in enumerate(unique.values(),1): print(f"{i}. {r['year']} | {r['title']} | {r['doi']}")
