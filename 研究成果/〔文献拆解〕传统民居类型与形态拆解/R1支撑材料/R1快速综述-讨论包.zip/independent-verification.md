## Source Verification Report

### Overall Assessment（最终限定核查）
- 范围：仅固定输入四组来源命题的本地原文抽核；不作正文、方案或正式研究论点。前四次实质采证后已保存阶段报告，再完成有界补核。
- **Sources Reviewed**：4；四组核心命题均 supported with caveats / attribution；两组有需保留的方法或数据转录警示（李冰杰、庄佳怡）；Rejected：0。以上是命题忠实度判定，不是来源真伪或全质量评级。
- 四份PDF均可打开并提取指定页文字。须保留对象层级、作者推辨及描述性比较的边界；不等于四份来源全流程验证。
- 视觉抽核未成功：尝试内存渲染张延安PDF35分类图及庄佳怡PDF2公式区；首次浏览器解释器缺fitz，改用已验证解释器后内存渲染成功，但浏览器data页导航出现BrokenPipeError，未取得可见截图。图示几何和图片公式具体形式仍not assessed；不把渲染程序成功说成视觉核查通过。未另存原文或图片。

### Per-claim verification
1. 李冰杰：supported with caveats。封面完成时间2023年5月，与文件名2025不同；PDF56–58（正文40–42）明确49户样本分单元型、纵向发展型、横向发展型，PDF60–61（正文44–45）另有78个合院细胞的一合、二合、三合、四合、H型。必须写“49户民居样本（作者用语）”，不推出独立住户总量。“分类对象层级须对齐”是本次核查的使用边界，不是作者原句。PDF57纵向样本编号出现重复2，尚未复算，不宜直接转用完整编号清单。
2. 张延安：supported with caveats。PDF34–36（正文25–27）按围合天井构成分单排屋、三合天井、四合天井、多进天井；PDF41（正文32）明确从实测及文献整理101栋、多聚落，随后比例模型；PDF120–121（正文111–112）支持比例量化及标准模型、二维和基本形态限制。“面积模型”作为独立模型类别，在本次指定页未取得足够定位：not assessed，不宜与比例标准模型并列写成已核结论。它的三合/四合与李冰杰在围合面数上有共同语义，不能说只是词面相同，但整宅平面类型与合院细胞不是相同分析层级，不能直接合并标签或频数。分类图与OCR待视觉复核。
3. 赵潇诺等：supported with attribution。PDF4–5（刊页13–14）3.1–3.3明确采用匠师手稿、典籍、实测数据推辨；通用型为院墙承重、方形后院天井、五柱四筒、屋面分层；作者辨认的原型为院墙不承重、后厨一字型天井、五柱四筒、屋面不分层。原型判断也使用“频率较高”，不能误写成完全不考虑频数；但不能以最高现状频数或已证实历史序列代替推辨。历史实证强度未全量审查。
4. 庄佳怡等：supported with methodological flags。PDF2（刊页6）各30处、四大类12小类；PDF3–4、6（刊页7–8、10）支持婺源较高、占地较小，金溪轮廓较平直、天井更狭长。PDF1–7为分地区描述性指标比较，不支持“统一统计聚类发现新类型”。文化等解释归作者，不作因果证明。初见指标疑点：破碎度公式为窗洞数/面积，却按百分数汇报；聚集度将无窗情形记为0，与极端聚集语义混用，需核公式图。天井均值长宽比与长宽均值之比并非必然相等，不能据此判错。

### Source Quality Matrix（限定任务）
| Source | Level | Venue | Author | Method | Currency | COI | Overall |
|---|---|---|---|---|---|---|---|
| 李冰杰 | VI（单项描述性研究，设计层级暂定） | not assessed | not assessed | 指定页命题抽核；全方法not assessed | not assessed | not assessed | 命题有据，非全源评级 |
| 张延安 | VI（同上） | not assessed | not assessed | 同上 | not assessed | not assessed | 命题有据，尺度须限定 |
| 赵潇诺等 | VI（同上） | not assessed | not assessed | 同上 | not assessed | not assessed | 作者推辨，非历史证成 |
| 庄佳怡等 | VI（同上） | not assessed | not assessed | 指标口径有待核疑点 | not assessed | not assessed | 描述性比较有据 |

### Flagged Sources (Detail)
- **李冰杰 / Low / Include with caveat**：PDF57（正文41）纵向发展型编号清单中的“2”出现两次；本次只指出转录可见重复，不认定聚类错误，不复算全样本。PDF56、61的核心分类和两个分析层级仍有明确文字支持。文件名年份不应覆盖封面“完成时间2023年5月”，但学位授予年、入库年not assessed。
- **张延安 / 尺度限定**：PDF34的分类对象写作“闽南古厝民居”，PDF35图3.1与PDF36图3.2涉及类型及生长；李冰杰PDF60是“合院细胞”。二者三合均有厅堂与两侧房间围天井的共同构成语义，四合均有四向建筑围合，但不能据此认为整套分类同构。李冰杰还明确区分房屋与墙体，并将H型计入细胞；张延安四分法包含多进天井。只有名称和部分构成相近，未完成跨论文等价映射；图示尺度、尺寸阈值和逐例判定：not assessed。
- **庄佳怡等 / Medium / Include with caveat**：以下是reader-inferred口径风险，不是对结果造假的认定。
  - PDF2（刊页6）破碎度为Ci=Ni/Ai，Ni为窗洞数、Ai为立面面积；PDF5（刊页9）用百分数汇报均值4.89%、6.96%。数量/面积与占比不是同一量纲；原文在已读方法与结果中未给出使它成为百分数的归一化说明，不宜直接当面积占比引用。
  - PDF2将聚集度0释为极端聚集，PDF5则将只有门、不开窗记为0，而其方法对象是窗洞重心。无窗样本与极端聚集不应默认混同；零值的计算/编码约定不明，不能据此确认具体程序算错。图片公式及原始数据未核。
  - PDF2虚化度总述提“门窗”，操作定义为窗洞面积/墙体面积；后文无窗样本是否仍计门洞不明，引用须按操作定义，不自动称全部开口率。
  - PDF4天井长宽比均值1.99、2.92，PDF6以约1:2和1:3表述；建议只复述长边/短边的数值，避免比例方向写反。“婺源偏方正”只是相对金溪，不是接近正方形的绝对判据。均值之比不等于比值均值，不能只凭前者不一致判为计算错误。
  - PDF3、4的关键描述值：正立面高宽比均值婺源0.82、金溪0.64；占地面积均值153、204平方米；正立面高低错落度均值35.27%、4.86%，侧立面19.34%、2.42%。这些是作者报告，未复算，也不等同统计显著差异。高宽比还受面阔影响，“较高”须连同层数叙述，不能只由比值推出绝对高度普遍更大。
- **赵潇诺等 / 归属限定**：PDF4–5的原型条件是作者推辨标准；作者还以“受当地环境影响最小、分型规律应用最少、使用频率较高”为筛选理由。本核查验证这一论证写法存在，不验证该标准必然识别真实历史起源。四柱落地是手稿推断的构造母题，不应直接替代作者最终五柱四筒侧样原型。

### Predatory Journal Alerts / Conflict of Interest Disclosures
- 均为not assessed；没有执行期刊合法性、掠夺性或利益冲突全量审查，不能解释为无风险。

### Verification Limitations
- 独立指本核查从固定输入直接核对指定原文，没有读取evidence.md，也没有以既有证据记录替代原文；不表示两独立来源证成。未读取或验证source_refs中的Paper证据记录。
- 所有长论文仅抽核下列指定页面。张延安PDF42图示OCR混乱，未据它判读全部样本图；核心分类与多聚落口径以PDF34、41文字为据。图片公式及图形细节保留未核；本报告不声称视觉核查或全部文献精读完成。
- Semantic Scholar / DOI / 外部数据库、作者、撤稿、期刊索引、全量元数据、全统计复算、2+独立来源交叉证成及ARS其他角色检查：not assessed。
- 未改Paper、Zotero或数据库；仅临时报告。使用AI辅助本地原文核查。

### Audit trail / actual_read_scope / source_locators
页码均为PDF物理页，另列论文印刷页；不是按阅读器自定义页标签估计。

| 原文绝对路径 | PDF总页数（工具实测） | 实际文本阅读范围 | SHA-256（原文件字节） |
|---|---:|---|---|
| `/Users/wangyuelin/Zotero/storage/UNEXNUUS/李冰杰 - 2025 - 类型学视角下徽州传统民居的空间形式特征研究.pdf` | 227 | PDF1封面；PDF54–61，正文38–45 | `d60f1b038d5fc0c79e8a0e56280a7bae94167c3acf97423df3b4484eea52dc76` |
| `/Users/wangyuelin/Zotero/storage/XT9W8IED/张延安 - 2017 - 建筑类型学下闽南古厝民居二维空间量化研究 ——以福建省土坑村民居为例.pdf` | 125 | PDF34–42，正文25–33；PDF120–121，正文111–112 | `30a2568c7e0d3ef9a85df3f48226ede793ce844ba553111b9f7c7da5c81214ca` |
| `/Users/wangyuelin/Zotero/storage/M2XVALGA/赵潇诺 等 - 2023 - 浙西南景宁畲族民居木构侧样研究.pdf` | 6 | PDF4–5，刊页13–14，§3.1–3.3及相邻内容 | `05b77ecafb7a1138fead55c9ba42467c4a037a1ed842d5faea8d57f84ec969bd` |
| `/Users/wangyuelin/Zotero/storage/JCIGHAWR/庄佳怡 等 - 2024 - 基于量化方法的徽派和赣派传统民居形态特征比较研究——以婺源县与金溪县为例.pdf` | 7 | PDF1–7，刊页5–11；补核PDF2文本坐标块与文件内元数据 | `d8198661b44ae382040370cac035faa6947696702855eaede91091db9fce5a31` |

- 固定输入：`/Users/wangyuelin/.hermes/profiles/academic/cache/scratch/r1-review-2ul17nx7/verification-input.md`；全文15行已读，SHA-256：`45d9c093ef1b8c8c14d3764a683ea01202ad73f5be1feabe75610e835c1f161d`。
- 所选角色原文、deep-research/WORKFLOW.md、nature-academic-search技能及其manifest/core/citation-verification流程、pdf技能均已实际加载；本任务服从固定输入的收窄授权，不扩展为全ARS调查。
- **execution_evidence**：前四次实质采证为四次本地PyMuPDF打开、逐页提取及SHA计算，均退出码0；随后write_file确认阶段报告落盘。补核文字及输入SHA成功；视觉路线第一次ModuleNotFoundError，第二次渲染完成但浏览器导航BrokenPipeError，故无视觉通过结果。未联网传送原文。
- **unresolved**：张延安图示尺度等价与图片判据、庄佳怡图片公式及零值编码/量纲澄清、李冰杰重复编号的实际原因。上述疑点不自动否决已有文字支持，也不由本核查替作者补定。
- **output_contract metadata**：actual_read_scope与source_locators见本表，unresolved见上，execution_evidence见上；仅候选核查报告交主会话，正式发布权仍在主会话。全部未执行的角色全量项目为 **not assessed**，不得宣传为ARS全流程验证。

