import collections, hashlib, html, json, re
from pathlib import Path
from markdown_it import MarkdownIt

B = Path(__file__).resolve().parent
search = json.loads((B/'search-results.json').read_text())
priority = {1,2,6,7,8,11,14,16,17,21,22,23,29,30}
background = {24,26,31,32,33,34,35,37,40,42,43}
not_pursued = set(range(1,46)) - priority - background
assert len(search['records']) == 45
assert not priority & background
labels = {}
for i,r in enumerate(search['records'],1):
    if i in priority:
        status = '住宅形态/类型候选，待摘要与全文核查'
        reason = '题名与住宅、构成或类型直接相关；未据题名接受研究结论'
    elif i in background:
        status = '理论或尺度背景候选，暂不进入民居实证综合'
        reason = '可能补充概念或较大尺度背景；尚未完成原文核读'
    else:
        status = '本轮不继续追读'
        reason = '题名侧重语言学、其他对象、性能专题或更宽泛主题；不是正式全文排除'
    r.update(disposition=status, reason=reason)
    labels[i] = status
counts = dict(collections.Counter(labels.values()))
search['disposition_counts'] = counts
search['possible_duplicate_groups'] = [
    {'indices':[21,30], 'status':'同题名、不同DOI，可能为同一报告，未按独立报告累计'},
    {'indices':[31,32], 'status':'同题名、年与DOI有差异，待出版者核查，未纳入正文'},
    {'indices':[42,43], 'status':'同题名、不同DOI，待核查，未纳入正文'}]
(B/'search-dispositions.json').write_text(json.dumps(search, ensure_ascii=False, indent=2))
keys='EQL74NWH K8ZWYEFW TJY6VMRY V5RJB5WJ CK2LERFG KJKB36XU 3VGHINZN 6TEACH2F C4R7XSWK YDR9ZFAR TN6XYSHX VT2P8MQX 2EEUF48G 3W4QE8RJ 5MAP72E6 69N3YWVJ DUJUISJF MVSSV45T N27YJCKR P2JU42S3 PD3FPKZ5 QAWMI8Z2 4825CYD6 72EKTVT7 88DFH34N A6F2XM3W E2EMLMGY EWW5YM35 F6XQ6NM5 J7A24EMN M6FLUJQ7 P2KHZ7AI RXAMXX8S ZI3KJPPV ZPQBX7YP'.split()
assert len(keys)==len(set(keys))==35
zotero={'query':'形态','qmode':'titleCreatorYear','limit':50,'returned':len(keys),'item_keys':keys,'new_full_text_used':['MVSSV45T'],'same_report_new_entry':{'old':'YTSWPLNA','active':'72EKTVT7'},'not_all_relevant':'题录检索含聚落、公共建筑、设计等非本轮核心；未全文筛完全部35条。','earlier_probe':'会话曾以typology查询(limit=30)；其完整结果未纳入本轮计数，不能据此给全会话合并命中总量。'}
(B/'zotero-search-log.json').write_text(json.dumps(zotero,ensure_ascii=False,indent=2))
lines=['# R1快速综述：补检索与去向记录','', '日期：2026-11-16。该记录是定向补检索，不是完整数据库筛选报告。', '', '## 查询与实际结果','', '| 来源 | 查询 | 限额 | 实际返回 | 状态 |','|---|---|---|---|---|']
for q in search['queries']:
    lines.append('| '+ ' | '.join([q['source'],q['query'],str(q['limit']),str(q['returned']) if q['returned'] is not None else '未获得结果',q.get('error','成功')])+' |')
lines.extend(['| Zotero | 形态（题名/作者/年子串匹配） | 50 | 35 | 成功；key见JSON |', '', 'Crossref实际取回45条题录；按DOI、缺DOI时按规范化题名的自动去重后仍为45条记录。这**不是45篇独立报告或研究**：不同DOI的同题名条目有3组，已标记待核查。未合计Zotero与Crossref为“全部独立文献”。', '', 'OpenAlex三次503保留为检索失败，不记作零篇命中。未调用带密钥或付费数据库，也没有CNKI/万方/WoS/Scopus的全库覆盖。', '', '## 实际使用及后续队列', '', '- 既有12篇报告的证据表和原生比较图作为种子，新增核读Zotero MVSSV45T（庄佳怡等，2024）全文7页，用于多维形态比较。', '- Crossref题录本轮没有直接进入研究结论。优先补读的线索包括住宅类型、院落构成和中国聚落向心图式；完整题名与DOI见下表。', '- 对Moudon题名命中的两个记录（31、32），以及向心图式论文（17），未取得可核全文。web_extract对期刊URL或DOI入口返回“Blocked: URL targets a private or internal network address”；这是当前提取通道失败，不证明原文不存在或DOI无效。', '- 前次探索性Zotero查询typology的完整返回未计入本日志；不据本表声称全会话检索总量。', '', '### 本轮题录去向汇总',''])
for label,count in counts.items(): lines.append(f'- {label}：{count}条。')
lines.extend(['', '这些是题录级阅读优先级，不是SR-screener双人纳排决定。“不继续追读”不表示文献无学术价值。', '', '| 序号 | 年份 | 题名 | DOI | 本轮去向 |','|---|---|---|---|---|'])
for i,r in enumerate(search['records'],1):
    title=re.sub('<[^>]+>','',r['title']).replace('|','／').replace('\n',' ')
    lines.append(f"| {i} | {r['year'] or '未给出'} | {title} | `{r['doi']}` | {r['disposition']} |")
lines.extend(['', '## 计数与状态说明', '', '- 来源题录的发表年和作者需回原文核对；不能把API录入/上线年直接当作最初出版年。', '- 对潜在重复只标记身份风险，不静默修补DOI或把题名相同当作附件相同。', '- 数值统计与文件校验为本轮程序执行结果；研究判断仍以讨论稿的原文定位和核查报告为准。'])
(B/'R1补检索记录.md').write_text('\n'.join(lines)+'\n')

md=MarkdownIt('commonmark',{'html':False}).enable('table')
source=B/'R1快速综述-讨论稿.md'
s=source.read_text()
refs=re.findall(r'^\[(\d+)\] ',s,re.M)
assert refs==[str(i) for i in range(1,14)],refs
comparison=s.split('## 三、报告级比较表')[1].split('## 四、')[0]
assert len(re.findall(r'^\| \[\d+\]',comparison,re.M))==13
assert not re.search(r'\b(?:TODO|TBD)\b|turn\d+search|待插入',s)
body=md.render(s)
styles='''body{font-family:-apple-system,BlinkMacSystemFont,"PingFang SC","Microsoft YaHei",sans-serif;color:#253240;background:#f5f6f8;margin:0;line-height:1.85}main{max-width:1100px;margin:28px auto;padding:30px 38px;background:#fff;border:1px solid #dce1e7;border-radius:10px}h1{font-size:28px;line-height:1.5}h2{font-size:23px;border-bottom:2px solid #c9d6dd;margin-top:40px}h3{font-size:19px;margin-top:26px;color:#245366}p,li{font-size:16px}table{border-collapse:collapse;width:100%;font-size:14px;margin:20px 0}th,td{border:1px solid #d9dfe5;padding:10px 12px;text-align:left;vertical-align:top}th{background:#edf3f5}code{font-size:13px;word-break:break-all;background:#f2f4f5}strong{color:#173e50}.table-scroll{overflow-x:auto}a{color:#145b78}@media(max-width:700px){main{margin:0;padding:18px;border:0;border-radius:0}table{min-width:850px}h1{font-size:24px}}@media print{body{background:#fff}main{max-width:none;border:0;padding:0}table{font-size:11px}h2,h3{break-after:avoid}}'''
body=body.replace('<table>','<div class="table-scroll"><table>').replace('</table>','</table></div>')
(B/'R1快速综述-阅读版.html').write_text('<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>R1快速综述讨论稿</title><style>'+styles+'</style></head><body><main>'+body+'</main></body></html>')
receipt={'seed_reports':12,'added_fulltext_reports':1,'comparison_rows':13,'reference_entries':len(refs),'crossref_retrieved_records':45,'crossref_dispositions':counts,'openalex_failed_queries':3,'zotero_shape_records':len(keys),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'rendered_html_sha256':hashlib.sha256((B/'R1快速综述-阅读版.html').read_bytes()).hexdigest(),'checks':['13 report rows equal 13 references','all 45 Crossref records assigned a disposition','35 Zotero result keys unique','no TODO/TBD/tool citation placeholders'],'not_covered':['scientific validity','independent review acceptance','Obsidian GUI','Paper publication']}
(B/'delivery-check.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2))
print(json.dumps(receipt,ensure_ascii=False,indent=2))
